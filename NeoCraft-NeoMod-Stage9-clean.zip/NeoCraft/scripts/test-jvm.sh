#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build/neomod-core-selftest.jar"
mkdir -p "$ROOT/build"
mapfile -t SOURCES < <(find \
  "$ROOT/neomod-core/src/main/kotlin" \
  "$ROOT/neomod-core/src/test/kotlin" \
  -type f -name '*.kt' | sort)
kotlinc "${SOURCES[@]}" -include-runtime -d "$OUT"
java -jar "$OUT"

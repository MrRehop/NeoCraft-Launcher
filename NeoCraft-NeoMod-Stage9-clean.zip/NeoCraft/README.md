# NeoCraft Launcher — Stage 9

NeoCraft is an open-source Android launcher project in development for Minecraft PE Patched. It combines a platform-neutral NeoMod package core with an Android package-discovery adapter and a minimal launcher application. Offline/LAN multiplayer and in-game mod loading are not implemented yet.

## Repository layout

- `app/` — minimal Android launcher Activity and package-visibility declaration.
- `android-integration/` — Android `PackageManager` adapter for installed-game identity.
- `neomod-core/` — platform-neutral Kotlin models, validation, `.nmod` ZIP reader and launcher-side package/profile manager.
- `neomod/`, `tools/`, `tests/` — Python reference implementation, package tools and tests.
- `spec/` — format, architecture and implementation status documents.
- `.github/workflows/` — core validation and Android debug-APK build workflows.

## Run the existing core tests

Python reference tests:

```bash
PYTHONPATH=. python -m unittest discover -s tests -v
```

Kotlin core self-tests (JDK and Kotlin compiler required):

```bash
./scripts/test-jvm.sh
```

## Android build baseline

- Android Gradle Plugin: 8.6.1
- Gradle: 8.7 for the Android workflow
- Kotlin: 1.9.0
- JDK: 17
- Compile SDK: 35
- Minimum SDK: 26 (Android 8.0)

The minimum SDK is 26 because the Kotlin package manager uses `java.nio.file` APIs, which Android exposes from API 26. Java 11 `Files.readString` / `Files.writeString` calls have been avoided; they are not available on Android 13 / API 33 according to the Android API reference. See `spec/STAGE9_ANDROID_API_COMPATIBILITY.md`.

## Current verification status

- Python reference tests: 10/10 passed in the current working environment.
- Kotlin core self-tests: 48/48 passed in the current working environment.
- Android Gradle compilation: not run in this environment.
- GitHub Actions build: not run or confirmed; no repository URL has been provided in this conversation.
- No installable APK is currently verified as produced.

## Game identity evidence supplied by the user

- Package name: `com.mojang.minecraftpe` (visible in App Manager screenshot).
- Display version: `1.26.13.1`.
- The number shown in parentheses (`792601301`) has not been confirmed as Android `versionCode`.
- User-provided signer SHA-256: `b369922ee3e720f359b9eec13af554dc87a0ec09f3ac49e7e123bc94fb985890`.

`AndroidGameDiscovery` must read the actual `longVersionCode` and current signer certificate from Android `PackageManager` on the device. The user-supplied values are not hardcoded into the supported-build registry. No actual Minecraft build is registered as compatible yet.

## Implementation boundary

NeoMod currently validates and inspects `.nmod` packages, manages launcher-side package files and profiles, and supports exact-match game identity records in the platform-neutral core. It does not inject or load mods into Minecraft, execute mod scripts, or implement offline/LAN multiplayer. The Stage 8 app only displays identity evidence and explicitly leaves compatibility unconfirmed.

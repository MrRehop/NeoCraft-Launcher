"""NeoMod v1 reference validator. Standard-library only; no game integration."""
from __future__ import annotations

import json
import re
import stat
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any
from zipfile import BadZipFile, ZipFile

ID_RE = re.compile(r"^[a-z0-9]+(?:[.-][a-z0-9]+)*\.[a-z0-9]+(?:[.-][a-z0-9]+)*$")
VERSION_RE = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
CAPABILITIES = {"textures", "sounds", "models", "ui", "behavior_data", "scripts"}
MAX_ENTRIES = 10_000
MAX_FILE_SIZE = 32 * 1024 * 1024
MAX_TOTAL_SIZE = 128 * 1024 * 1024
MAX_MANIFEST_SIZE = 256 * 1024


class NeoModError(ValueError):
    pass


@dataclass(frozen=True)
class Resource:
    source: str
    target: str
    capability: str


@dataclass(frozen=True)
class Dependency:
    mod_id: str
    constraint: str
    optional: bool


@dataclass(frozen=True)
class Package:
    path: str
    mod_id: str
    name: str
    version: str
    game_versions: tuple[str, ...]
    dependencies: tuple[Dependency, ...]
    conflicts: tuple[str, ...]
    capabilities: frozenset[str]
    resources: tuple[Resource, ...]


def _safe_relative_path(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value or ":" in value:
        raise NeoModError(f"{field} must be a non-empty POSIX relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise NeoModError(f"unsafe {field}: {value}")
    normalized = path.as_posix()
    if normalized != value:
        raise NeoModError(f"{field} must be normalized: {value}")
    return normalized


def _version(value: Any, field: str) -> tuple[int, int, int]:
    if not isinstance(value, str):
        raise NeoModError(f"{field} must be a semantic version string")
    match = VERSION_RE.fullmatch(value)
    if not match:
        raise NeoModError(f"{field} must use stable MAJOR.MINOR.PATCH, got {value!r}")
    return tuple(int(part) for part in match.groups())


def _satisfies(version: tuple[int, int, int], constraint: str) -> bool:
    """Supported grammar: comma-separated clauses using >=, <=, >, <, = or bare exact version."""
    if not isinstance(constraint, str) or not constraint.strip():
        raise NeoModError("dependency version constraint must be a non-empty string")
    clauses = []
    for raw_clause in constraint.split(","):
        clause = raw_clause.strip()
        match = re.fullmatch(r"(>=|<=|>|<|=)?\s*(\d+\.\d+\.\d+)", clause)
        if not match:
            raise NeoModError(f"unsupported dependency constraint: {constraint!r}")
        operator, raw_version = match.groups()
        required = _version(raw_version, "dependency.version")
        clauses.append((operator or "=", required))
    for op, required in clauses:
        checks = {
            ">=": version >= required,
            "<=": version <= required,
            ">": version > required,
            "<": version < required,
            "=": version == required,
        }
        if not checks[op]:
            return False
    return True


def _validate_manifest(manifest: Any, archive_names: set[str]) -> Package:
    if not isinstance(manifest, dict):
        raise NeoModError("manifest root must be a JSON object")
    allowed_keys = {
        "format_version", "id", "name", "version", "author", "description",
        "game", "dependencies", "conflicts", "capabilities", "resources", "entrypoint"
    }
    unknown = set(manifest) - allowed_keys
    if unknown:
        raise NeoModError(f"unknown manifest fields: {', '.join(sorted(unknown))}")
    required = {"format_version", "id", "name", "version", "game", "dependencies", "conflicts", "capabilities", "resources"}
    missing = required - set(manifest)
    if missing:
        raise NeoModError(f"missing manifest fields: {', '.join(sorted(missing))}")
    if manifest["format_version"] != 1:
        raise NeoModError("unsupported format_version; expected 1")

    mod_id = manifest["id"]
    if not isinstance(mod_id, str) or not ID_RE.fullmatch(mod_id):
        raise NeoModError("id must be a lowercase reverse-DNS identifier, e.g. org.example.mod")
    name = manifest["name"]
    if not isinstance(name, str) or not name.strip() or len(name) > 80:
        raise NeoModError("name must contain 1..80 characters")
    for optional_text in ("author", "description"):
        if optional_text in manifest:
            value = manifest[optional_text]
            limit = 80 if optional_text == "author" else 500
            if not isinstance(value, str) or len(value) > limit:
                raise NeoModError(f"{optional_text} must be a string of at most {limit} characters")
    version_text = manifest["version"]
    _version(version_text, "version")

    game = manifest["game"]
    if not isinstance(game, dict) or set(game) != {"id", "versions"}:
        raise NeoModError("game must contain exactly id and versions")
    if game["id"] != "minecraft-bedrock":
        raise NeoModError("game.id must be minecraft-bedrock in manifest v1")
    game_versions = game["versions"]
    if not isinstance(game_versions, list) or not game_versions or not all(isinstance(v, str) and v for v in game_versions):
        raise NeoModError("game.versions must be a non-empty array of version labels")

    raw_dependencies = manifest["dependencies"]
    if not isinstance(raw_dependencies, list):
        raise NeoModError("dependencies must be an array")
    dependencies: list[Dependency] = []
    seen_dependencies: set[str] = set()
    for item in raw_dependencies:
        if not isinstance(item, dict) or set(item) != {"id", "version", "optional"}:
            raise NeoModError("each dependency must contain exactly id, version, optional")
        dep_id = item["id"]
        if not isinstance(dep_id, str) or not ID_RE.fullmatch(dep_id) or dep_id == mod_id:
            raise NeoModError(f"invalid dependency id: {dep_id!r}")
        if dep_id in seen_dependencies:
            raise NeoModError(f"duplicate dependency: {dep_id}")
        seen_dependencies.add(dep_id)
        # Parse now so malformed constraints are rejected even if optional dependency is absent.
        _satisfies((0, 0, 0), item["version"])
        if not isinstance(item["optional"], bool):
            raise NeoModError(f"dependency {dep_id}: optional must be boolean")
        dependencies.append(Dependency(dep_id, item["version"], item["optional"]))

    raw_conflicts = manifest["conflicts"]
    if not isinstance(raw_conflicts, list) or not all(isinstance(x, str) and ID_RE.fullmatch(x) for x in raw_conflicts):
        raise NeoModError("conflicts must be an array of valid mod IDs")
    if len(raw_conflicts) != len(set(raw_conflicts)) or mod_id in raw_conflicts:
        raise NeoModError("conflicts must be unique and cannot contain this mod's own ID")

    raw_capabilities = manifest["capabilities"]
    if not isinstance(raw_capabilities, list) or not all(isinstance(x, str) for x in raw_capabilities):
        raise NeoModError("capabilities must be an array of strings")
    if len(raw_capabilities) != len(set(raw_capabilities)):
        raise NeoModError("capabilities must not contain duplicates")
    if not set(raw_capabilities).issubset(CAPABILITIES):
        raise NeoModError(f"unknown capabilities: {sorted(set(raw_capabilities) - CAPABILITIES)}")

    raw_resources = manifest["resources"]
    if not isinstance(raw_resources, list):
        raise NeoModError("resources must be an array")
    resources: list[Resource] = []
    seen_targets: set[str] = set()
    for item in raw_resources:
        if not isinstance(item, dict) or set(item) != {"source", "target", "capability"}:
            raise NeoModError("each resource must contain exactly source, target, capability")
        source = _safe_relative_path(item["source"], "resource.source")
        target = _safe_relative_path(item["target"], "resource.target")
        capability = item["capability"]
        if not isinstance(capability, str) or capability not in CAPABILITIES or capability not in raw_capabilities:
            raise NeoModError(f"resource capability is not declared by package: {capability!r}")
        if source not in archive_names:
            raise NeoModError(f"resource source does not exist in package: {source}")
        target_key = target.casefold()
        if target_key in seen_targets:
            raise NeoModError(f"duplicate resource target inside package: {target}")
        seen_targets.add(target_key)
        resources.append(Resource(source, target, capability))

    entrypoint = manifest.get("entrypoint")
    if entrypoint is not None:
        entrypoint = _safe_relative_path(entrypoint, "entrypoint")
        if entrypoint not in archive_names:
            raise NeoModError(f"entrypoint does not exist: {entrypoint}")
        if "scripts" not in raw_capabilities:
            raise NeoModError("entrypoint requires the scripts capability")

    return Package(
        path="", mod_id=mod_id, name=name, version=version_text,
        game_versions=tuple(game_versions), dependencies=tuple(dependencies),
        conflicts=tuple(raw_conflicts), capabilities=frozenset(raw_capabilities),
        resources=tuple(resources)
    )


def load_package(path: str) -> Package:
    try:
        with ZipFile(path) as archive:
            infos = archive.infolist()
            if len(infos) > MAX_ENTRIES:
                raise NeoModError(f"archive has too many entries (limit {MAX_ENTRIES})")
            names: set[str] = set()
            file_names: set[str] = set()
            folded_names: set[str] = set()
            total_size = 0
            for info in infos:
                name = info.filename
                is_directory = info.is_dir() or name.endswith("/")
                if is_directory:
                    name = name.rstrip("/")
                if not name:
                    continue
                safe = _safe_relative_path(name, "archive entry")
                folded = safe.casefold()
                if safe in names or folded in folded_names:
                    raise NeoModError(f"duplicate or case-colliding archive entry: {safe}")
                names.add(safe)
                folded_names.add(folded)
                mode = info.external_attr >> 16
                if stat.S_ISLNK(mode):
                    raise NeoModError(f"symbolic links are not allowed: {safe}")
                if info.file_size > MAX_FILE_SIZE:
                    raise NeoModError(f"file too large: {safe}")
                if not is_directory:
                    file_names.add(safe)
                total_size += info.file_size
                if total_size > MAX_TOTAL_SIZE:
                    raise NeoModError("uncompressed package exceeds size limit")
            if "manifest.json" not in names:
                raise NeoModError("manifest.json is missing from archive root")
            info = archive.getinfo("manifest.json")
            if info.file_size > MAX_MANIFEST_SIZE:
                raise NeoModError("manifest.json exceeds size limit")
            try:
                manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise NeoModError(f"manifest.json is not valid UTF-8 JSON: {exc}") from exc
            package = _validate_manifest(manifest, file_names)
            return Package(**{**package.__dict__, "path": path})
    except BadZipFile as exc:
        raise NeoModError("file is not a valid ZIP-based .nmod package") from exc


def validate_profile(packages: list[Package]) -> list[str]:
    errors: list[str] = []
    by_id: dict[str, Package] = {}
    for package in packages:
        if package.mod_id in by_id:
            errors.append(f"duplicate mod ID {package.mod_id}: {by_id[package.mod_id].path} and {package.path}")
        else:
            by_id[package.mod_id] = package

    for package in packages:
        for conflict_id in package.conflicts:
            if conflict_id in by_id:
                errors.append(f"declared conflict: {package.mod_id} conflicts with {conflict_id}")
        for dependency in package.dependencies:
            target = by_id.get(dependency.mod_id)
            if target is None:
                if not dependency.optional:
                    errors.append(f"missing dependency: {package.mod_id} requires {dependency.mod_id} {dependency.constraint}")
                continue
            if not _satisfies(_version(target.version, "installed package version"), dependency.constraint):
                errors.append(f"dependency version mismatch: {package.mod_id} requires {dependency.mod_id} {dependency.constraint}, found {target.version}")

    # Detect dependency cycles among packages present in the profile.
    graph = {p.mod_id: [d.mod_id for d in p.dependencies if d.mod_id in by_id] for p in packages if p.mod_id in by_id}
    visiting: set[str] = set()
    visited: set[str] = set()
    def visit(node: str, stack: list[str]) -> None:
        if node in visiting:
            cycle = stack[stack.index(node):] + [node]
            errors.append("dependency cycle: " + " -> ".join(cycle))
            return
        if node in visited:
            return
        visiting.add(node)
        for nxt in graph.get(node, []):
            visit(nxt, stack + [nxt])
        visiting.remove(node)
        visited.add(node)
    for node in graph:
        if node not in visited:
            visit(node, [node])

    targets: dict[str, tuple[str, str]] = {}
    for package in packages:
        for resource in package.resources:
            key = resource.target.casefold()
            previous = targets.get(key)
            if previous and previous[0] != package.mod_id:
                errors.append(f"resource target collision: {resource.target} is mapped by {previous[0]} and {package.mod_id}")
            else:
                targets[key] = (package.mod_id, resource.source)
    return errors

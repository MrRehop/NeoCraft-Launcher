import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from neomod.core import NeoModError, load_package, validate_profile

BASE_MANIFEST = {
    "format_version": 1,
    "id": "org.neocraft.alpha",
    "name": "Alpha",
    "version": "1.2.0",
    "game": {"id": "minecraft-bedrock", "versions": ["1.21.x"]},
    "dependencies": [],
    "conflicts": [],
    "capabilities": ["textures"],
    "resources": [{"source": "assets/a.bin", "target": "textures/a.bin", "capability": "textures"}],
}


def make_package(path: Path, manifest: dict, extra=None):
    with ZipFile(path, "w", ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps(manifest))
        z.writestr("assets/a.bin", b"x")
        for name, data in (extra or {}).items():
            z.writestr(name, data)
    return path


class NeoModTests(unittest.TestCase):
    def test_valid_package_loads(self):
        with tempfile.TemporaryDirectory() as td:
            path = make_package(Path(td) / "a.nmod", dict(BASE_MANIFEST))
            package = load_package(str(path))
            self.assertEqual(package.mod_id, "org.neocraft.alpha")

    def test_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "bad.nmod"
            with ZipFile(path, "w") as z:
                z.writestr("manifest.json", json.dumps(BASE_MANIFEST))
                z.writestr("../escape.txt", "bad")
            with self.assertRaises(NeoModError):
                load_package(str(path))

    def test_missing_resource_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            manifest = dict(BASE_MANIFEST)
            manifest["resources"] = [{"source": "missing.png", "target": "textures/x.png", "capability": "textures"}]
            path = make_package(Path(td) / "missing.nmod", manifest)
            with self.assertRaisesRegex(NeoModError, "does not exist"):
                load_package(str(path))

    def test_required_dependency_missing(self):
        with tempfile.TemporaryDirectory() as td:
            manifest = dict(BASE_MANIFEST)
            manifest["dependencies"] = [{"id": "org.neocraft.core", "version": ">=1.0.0,<2.0.0", "optional": False}]
            path = make_package(Path(td) / "a.nmod", manifest)
            errors = validate_profile([load_package(str(path))])
            self.assertTrue(any("missing dependency" in e for e in errors))

    def test_cross_package_resource_collision(self):
        with tempfile.TemporaryDirectory() as td:
            m1 = dict(BASE_MANIFEST)
            m2 = dict(BASE_MANIFEST)
            m2["id"] = "org.neocraft.beta"
            m2["name"] = "Beta"
            p1 = make_package(Path(td) / "a.nmod", m1)
            p2 = make_package(Path(td) / "b.nmod", m2)
            errors = validate_profile([load_package(str(p1)), load_package(str(p2))])
            self.assertTrue(any("resource target collision" in e for e in errors))

    def test_declared_conflict_detected(self):
        with tempfile.TemporaryDirectory() as td:
            m1 = dict(BASE_MANIFEST)
            m1["conflicts"] = ["org.neocraft.beta"]
            m2 = dict(BASE_MANIFEST)
            m2["id"] = "org.neocraft.beta"
            m2["name"] = "Beta"
            p1 = make_package(Path(td) / "a.nmod", m1)
            p2 = make_package(Path(td) / "b.nmod", m2)
            errors = validate_profile([load_package(str(p1)), load_package(str(p2))])
            self.assertTrue(any("declared conflict" in e for e in errors))

    def test_invalid_later_dependency_clause_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            manifest = dict(BASE_MANIFEST)
            manifest["dependencies"] = [{"id": "org.neocraft.core", "version": ">=9.0.0,not-a-range", "optional": True}]
            path = make_package(Path(td) / "bad-range.nmod", manifest)
            with self.assertRaisesRegex(NeoModError, "unsupported dependency constraint"):
                load_package(str(path))

    def test_dependency_version_mismatch(self):
        with tempfile.TemporaryDirectory() as td:
            consumer = dict(BASE_MANIFEST)
            consumer["dependencies"] = [{"id": "org.neocraft.core", "version": ">=2.0.0,<3.0.0", "optional": False}]
            core = dict(BASE_MANIFEST)
            core["id"] = "org.neocraft.core"
            core["name"] = "Core"
            core["version"] = "1.5.0"
            p1 = make_package(Path(td) / "consumer.nmod", consumer)
            p2 = make_package(Path(td) / "core.nmod", core)
            errors = validate_profile([load_package(str(p1)), load_package(str(p2))])
            self.assertTrue(any("dependency version mismatch" in e for e in errors))

    def test_dependency_cycle_detected(self):
        with tempfile.TemporaryDirectory() as td:
            a = dict(BASE_MANIFEST)
            b = dict(BASE_MANIFEST)
            b["id"] = "org.neocraft.beta"
            b["name"] = "Beta"
            # A and B depend on each other.
            a["dependencies"] = [{"id": "org.neocraft.beta", "version": ">=1.0.0", "optional": False}]
            b["dependencies"] = [{"id": "org.neocraft.alpha", "version": ">=1.0.0", "optional": False}]
            p1 = make_package(Path(td) / "a.nmod", a)
            p2 = make_package(Path(td) / "b.nmod", b)
            errors = validate_profile([load_package(str(p1)), load_package(str(p2))])
            self.assertTrue(any("dependency cycle" in e for e in errors))

    def test_optional_metadata_type_checked(self):
        with tempfile.TemporaryDirectory() as td:
            manifest = dict(BASE_MANIFEST)
            manifest["author"] = ["not", "a", "string"]
            path = make_package(Path(td) / "bad-author.nmod", manifest)
            with self.assertRaisesRegex(NeoModError, "author must be a string"):
                load_package(str(path))


if __name__ == "__main__":
    unittest.main()

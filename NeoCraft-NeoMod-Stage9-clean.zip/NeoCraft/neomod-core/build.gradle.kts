plugins {
    kotlin("jvm")
}

kotlin {
    jvmToolchain(17)
}

// The core intentionally has no Android or Minecraft dependency.

tasks.register<JavaExec>("selfTest") {
    dependsOn(tasks.testClasses)
    classpath = sourceSets["test"].runtimeClasspath
    mainClass.set("org.neocraft.neomod.core.NeoModCoreSelfTestKt")
}

package org.neocraft.neomod.core

/** Small strict JSON parser used to keep NeoMod Core independent of Android and third-party libraries. */
internal sealed interface NeoJsonValue {
    data class ObjectValue(val values: Map<String, NeoJsonValue>) : NeoJsonValue {
        operator fun get(key: String): NeoJsonValue? = values[key]
    }
    data class ArrayValue(val values: List<NeoJsonValue>) : NeoJsonValue
    data class StringValue(val value: String) : NeoJsonValue
    data class NumberValue(val value: String) : NeoJsonValue
    data class BooleanValue(val value: Boolean) : NeoJsonValue
    data object NullValue : NeoJsonValue
}

internal class NeoJsonParser(private val source: String) {
    private var index = 0

    fun parse(): NeoJsonValue {
        skipWhitespace()
        val value = parseValue()
        skipWhitespace()
        if (index != source.length) error("unexpected content after JSON value")
        return value
    }

    private fun parseValue(): NeoJsonValue {
        if (index >= source.length) error("unexpected end of JSON")
        return when (source[index]) {
            '{' -> parseObject()
            '[' -> parseArray()
            '"' -> NeoJsonValue.StringValue(parseString())
            't' -> { consumeLiteral("true"); NeoJsonValue.BooleanValue(true) }
            'f' -> { consumeLiteral("false"); NeoJsonValue.BooleanValue(false) }
            'n' -> { consumeLiteral("null"); NeoJsonValue.NullValue }
            '-', in '0'..'9' -> parseNumber()
            else -> error("unexpected character '${source[index]}'")
        }
    }

    private fun parseObject(): NeoJsonValue.ObjectValue {
        expect('{')
        skipWhitespace()
        val values = linkedMapOf<String, NeoJsonValue>()
        if (take('}')) return NeoJsonValue.ObjectValue(values)
        while (true) {
            skipWhitespace()
            if (index >= source.length || source[index] != '"') error("object key must be a string")
            val key = parseString()
            skipWhitespace()
            expect(':')
            skipWhitespace()
            val value = parseValue()
            if (values.put(key, value) != null) error("duplicate JSON object key '$key'")
            skipWhitespace()
            if (take('}')) break
            expect(',')
        }
        return NeoJsonValue.ObjectValue(values)
    }

    private fun parseArray(): NeoJsonValue.ArrayValue {
        expect('[')
        skipWhitespace()
        val values = mutableListOf<NeoJsonValue>()
        if (take(']')) return NeoJsonValue.ArrayValue(values)
        while (true) {
            skipWhitespace()
            values += parseValue()
            skipWhitespace()
            if (take(']')) break
            expect(',')
        }
        return NeoJsonValue.ArrayValue(values)
    }

    private fun parseString(): String {
        expect('"')
        val result = StringBuilder()
        while (index < source.length) {
            val ch = source[index++]
            when {
                ch == '"' -> return result.toString()
                ch == '\\' -> {
                    if (index >= source.length) error("unterminated escape sequence")
                    when (val escaped = source[index++]) {
                        '"' -> result.append('"')
                        '\\' -> result.append('\\')
                        '/' -> result.append('/')
                        'b' -> result.append('\b')
                        'f' -> result.append('\u000C')
                        'n' -> result.append('\n')
                        'r' -> result.append('\r')
                        't' -> result.append('\t')
                        'u' -> {
                            if (index + 4 > source.length) error("incomplete Unicode escape")
                            val hex = source.substring(index, index + 4)
                            val code = hex.toIntOrNull(16) ?: error("invalid Unicode escape")
                            result.append(code.toChar())
                            index += 4
                        }
                        else -> error("invalid escape '\\$escaped'")
                    }
                }
                ch.code < 0x20 -> error("unescaped control character in string")
                else -> result.append(ch)
            }
        }
        error("unterminated JSON string")
    }

    private fun parseNumber(): NeoJsonValue.NumberValue {
        val start = index
        take('-')
        if (take('0')) {
            if (index < source.length && source[index] in '0'..'9') error("leading zero in number")
        } else {
            consumeDigits(required = true)
        }
        if (take('.')) consumeDigits(required = true)
        if (take('e') || take('E')) {
            if (!take('+')) take('-')
            consumeDigits(required = true)
        }
        return NeoJsonValue.NumberValue(source.substring(start, index))
    }

    private fun consumeDigits(required: Boolean) {
        val start = index
        while (index < source.length && source[index] in '0'..'9') index++
        if (required && start == index) error("expected digit")
    }

    private fun consumeLiteral(literal: String) {
        if (!source.startsWith(literal, index)) error("expected '$literal'")
        index += literal.length
    }

    private fun skipWhitespace() {
        while (index < source.length && (source[index] == ' ' || source[index] == '\n' || source[index] == '\r' || source[index] == '\t')) index++
    }

    private fun expect(ch: Char) {
        if (!take(ch)) error("expected '$ch'")
    }

    private fun take(ch: Char): Boolean {
        if (index < source.length && source[index] == ch) {
            index++
            return true
        }
        return false
    }

    private fun error(message: String): Nothing =
        throw NeoModValidationException("invalid manifest JSON at character $index: $message")
}

internal object NeoModManifestDecoder {
    private val rootKeys = setOf(
        "format_version", "id", "name", "version", "author", "description", "game",
        "dependencies", "conflicts", "capabilities", "resources", "entrypoint"
    )

    fun decode(json: String): NeoModManifest {
        val root = NeoJsonParser(json).parse().asObject("manifest")
        rejectUnknown(root, rootKeys, "manifest")
        val game = root.required("game").asObject("game")
        rejectUnknown(game, setOf("id", "versions"), "game")

        val dependencies = root.optionalArray("dependencies").mapIndexed { index, item ->
            val obj = item.asObject("dependencies[$index]")
            rejectUnknown(obj, setOf("id", "version", "optional"), "dependencies[$index]")
            NeoModDependency(
                modId = obj.required("id").asString("dependencies[$index].id"),
                versionConstraint = obj.required("version").asString("dependencies[$index].version"),
                optional = obj["optional"]?.asBoolean("dependencies[$index].optional") ?: false,
            )
        }

        val resources = root.optionalArray("resources").mapIndexed { index, item ->
            val obj = item.asObject("resources[$index]")
            rejectUnknown(obj, setOf("source", "target", "capability"), "resources[$index]")
            NeoModResource(
                source = obj.required("source").asString("resources[$index].source"),
                target = obj.required("target").asString("resources[$index].target"),
                capability = obj.required("capability").asString("resources[$index].capability"),
            )
        }

        val capabilityList = root.optionalArray("capabilities").mapIndexed { i, v -> v.asString("capabilities[$i]") }
        if (capabilityList.size != capabilityList.toSet().size) {
            throw NeoModValidationException("capabilities must not contain duplicate values")
        }

        val entrypoint = when (val value = root["entrypoint"]) {
            null, NeoJsonValue.NullValue -> null
            else -> value.asString("entrypoint")
        }

        return NeoModManifest(
            formatVersion = root.required("format_version").asInt("format_version"),
            id = root.required("id").asString("id"),
            name = root.required("name").asString("name"),
            version = root.required("version").asString("version"),
            gameId = game.required("id").asString("game.id"),
            gameVersions = game.required("versions").asStringArray("game.versions"),
            dependencies = dependencies,
            conflicts = root.optionalArray("conflicts").mapIndexed { i, v -> v.asString("conflicts[$i]") },
            capabilities = capabilityList.toSet(),
            resources = resources,
            author = root.optionalString("author"),
            description = root.optionalString("description"),
            entrypoint = entrypoint,
        )
    }

    private fun rejectUnknown(obj: NeoJsonValue.ObjectValue, allowed: Set<String>, where: String) {
        val unknown = obj.values.keys - allowed
        if (unknown.isNotEmpty()) throw NeoModValidationException("unknown $where field(s): ${unknown.sorted()}")
    }
}

private fun NeoJsonValue.asObject(field: String): NeoJsonValue.ObjectValue =
    this as? NeoJsonValue.ObjectValue ?: throw NeoModValidationException("$field must be an object")

private fun NeoJsonValue.asString(field: String): String =
    (this as? NeoJsonValue.StringValue)?.value ?: throw NeoModValidationException("$field must be a string")

private fun NeoJsonValue.asBoolean(field: String): Boolean =
    (this as? NeoJsonValue.BooleanValue)?.value ?: throw NeoModValidationException("$field must be a boolean")

private fun NeoJsonValue.asInt(field: String): Int {
    val raw = (this as? NeoJsonValue.NumberValue)?.value
        ?: throw NeoModValidationException("$field must be an integer")
    return raw.toIntOrNull() ?: throw NeoModValidationException("$field must be a 32-bit integer")
}

private fun NeoJsonValue.asStringArray(field: String): List<String> =
    (this as? NeoJsonValue.ArrayValue)?.values?.mapIndexed { i, value -> value.asString("$field[$i]") }
        ?: throw NeoModValidationException("$field must be an array")

private fun NeoJsonValue.ObjectValue.required(key: String): NeoJsonValue =
    values[key] ?: throw NeoModValidationException("missing required field '$key'")

private fun NeoJsonValue.ObjectValue.optionalArray(key: String): List<NeoJsonValue> = when (val value = values[key]) {
    null -> emptyList()
    is NeoJsonValue.ArrayValue -> value.values
    else -> throw NeoModValidationException("$key must be an array")
}

private fun NeoJsonValue.ObjectValue.optionalString(key: String): String? = when (val value = values[key]) {
    null, NeoJsonValue.NullValue -> null
    is NeoJsonValue.StringValue -> value.value
    else -> throw NeoModValidationException("$key must be a string or null")
}

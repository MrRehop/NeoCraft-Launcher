package org.neocraft.neomod.core

/** Platform-neutral implementation of the validation rules in NeoMod package format v1. */
object NeoModValidator {
    private val idRegex = Regex("^[a-z0-9]+(?:[.-][a-z0-9]+)*\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$")
    private val versionRegex = Regex("^(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)$")
    private val constraintClauseRegex = Regex("^(>=|<=|>|<|=)?\\s*(\\d+\\.\\d+\\.\\d+)$")

    val supportedCapabilities: Set<String> = setOf(
        "textures", "sounds", "models", "ui", "behavior_data", "scripts"
    )

    data class SemanticVersion(val major: Int, val minor: Int, val patch: Int) : Comparable<SemanticVersion> {
        override fun compareTo(other: SemanticVersion): Int =
            compareValuesBy(this, other, SemanticVersion::major, SemanticVersion::minor, SemanticVersion::patch)

        override fun toString(): String = "$major.$minor.$patch"
    }

    fun parseVersion(value: String, field: String = "version"): SemanticVersion {
        val match = versionRegex.matchEntire(value)
            ?: throw NeoModValidationException("$field must use stable MAJOR.MINOR.PATCH, got '$value'")
        return SemanticVersion(
            match.groupValues[1].toIntOrNull() ?: throw NeoModValidationException("$field major is too large"),
            match.groupValues[2].toIntOrNull() ?: throw NeoModValidationException("$field minor is too large"),
            match.groupValues[3].toIntOrNull() ?: throw NeoModValidationException("$field patch is too large"),
        )
    }

    fun isVersionSatisfied(installedVersion: String, constraint: String): Boolean {
        val installed = parseVersion(installedVersion, "installed package version")
        if (constraint.isBlank()) {
            throw NeoModValidationException("dependency version constraint must be a non-empty string")
        }
        val clauses = constraint.split(',').map { raw ->
            val match = constraintClauseRegex.matchEntire(raw.trim())
                ?: throw NeoModValidationException("unsupported dependency constraint: '$constraint'")
            val operator = match.groupValues[1].ifEmpty { "=" }
            val required = parseVersion(match.groupValues[2], "dependency.version")
            operator to required
        }
        return clauses.all { (operator, required) ->
            when (operator) {
                ">=" -> installed >= required
                "<=" -> installed <= required
                ">" -> installed > required
                "<" -> installed < required
                "=" -> installed == required
                else -> false
            }
        }
    }

    fun validateManifest(manifest: NeoModManifest, archiveFileNames: Set<String>) {
        if (manifest.formatVersion != 1) fail("unsupported format_version; expected 1")
        if (!idRegex.matches(manifest.id)) {
            fail("id must be a lowercase reverse-DNS identifier, e.g. org.example.mod")
        }
        if (manifest.name.isBlank() || manifest.name.length > 80) {
            fail("name must contain 1..80 characters")
        }
        manifest.author?.let { if (it.length > 80) fail("author must be a string of at most 80 characters") }
        manifest.description?.let { if (it.length > 500) fail("description must be a string of at most 500 characters") }
        parseVersion(manifest.version)

        if (manifest.gameId != "minecraft-bedrock") {
            fail("game.id must be minecraft-bedrock in manifest v1")
        }
        if (manifest.gameVersions.isEmpty() || manifest.gameVersions.any { it.isBlank() }) {
            fail("game.versions must be a non-empty array of version labels")
        }

        val dependencyIds = mutableSetOf<String>()
        manifest.dependencies.forEach { dependency ->
            if (!idRegex.matches(dependency.modId) || dependency.modId == manifest.id) {
                fail("invalid dependency id: '${dependency.modId}'")
            }
            if (!dependencyIds.add(dependency.modId)) fail("duplicate dependency: ${dependency.modId}")
            // Validate syntax even when an optional dependency is not installed.
            isVersionSatisfied("0.0.0", dependency.versionConstraint)
        }

        if (manifest.conflicts.any { !idRegex.matches(it) }) {
            fail("conflicts must be an array of valid mod IDs")
        }
        if (manifest.conflicts.size != manifest.conflicts.toSet().size || manifest.id in manifest.conflicts) {
            fail("conflicts must be unique and cannot contain this mod's own ID")
        }

        if (!supportedCapabilities.containsAll(manifest.capabilities)) {
            val unknown = manifest.capabilities - supportedCapabilities
            fail("unknown capabilities: ${unknown.sorted()}")
        }

        val targets = mutableSetOf<String>()
        manifest.resources.forEach { resource ->
            validateRelativePath(resource.source, "resource.source")
            validateRelativePath(resource.target, "resource.target")
            if (resource.capability !in supportedCapabilities || resource.capability !in manifest.capabilities) {
                fail("resource capability is not declared by package: '${resource.capability}'")
            }
            if (resource.source !in archiveFileNames) {
                fail("resource source does not exist in package: ${resource.source}")
            }
            if (!targets.add(resource.target.lowercase())) {
                fail("duplicate resource target inside package: ${resource.target}")
            }
        }

        manifest.entrypoint?.let { entrypoint ->
            validateRelativePath(entrypoint, "entrypoint")
            if (entrypoint !in archiveFileNames) fail("entrypoint does not exist: $entrypoint")
            if ("scripts" !in manifest.capabilities) fail("entrypoint requires the scripts capability")
        }
    }

    /** Returns all profile errors; an empty list means metadata-level validation passed. */
    fun validateProfile(packages: List<NeoModPackage>): List<String> {
        val errors = mutableListOf<String>()
        val byId = linkedMapOf<String, NeoModPackage>()
        packages.forEach { packageEntry ->
            val id = packageEntry.manifest.id
            val previous = byId[id]
            if (previous != null) {
                errors += "duplicate mod ID $id: ${previous.path} and ${packageEntry.path}"
            } else {
                byId[id] = packageEntry
            }
        }

        packages.forEach { packageEntry ->
            val manifest = packageEntry.manifest
            manifest.conflicts.forEach { conflictId ->
                if (conflictId in byId) errors += "declared conflict: ${manifest.id} conflicts with $conflictId"
            }
            manifest.dependencies.forEach { dependency ->
                val target = byId[dependency.modId]
                if (target == null) {
                    if (!dependency.optional) {
                        errors += "missing dependency: ${manifest.id} requires ${dependency.modId} ${dependency.versionConstraint}"
                    }
                } else if (!isVersionSatisfied(target.manifest.version, dependency.versionConstraint)) {
                    errors += "dependency version mismatch: ${manifest.id} requires ${dependency.modId} ${dependency.versionConstraint}, found ${target.manifest.version}"
                }
            }
        }

        // DFS cycle detection over dependencies that are present in this profile.
        val graph = byId.mapValues { (_, packageEntry) ->
            packageEntry.manifest.dependencies.mapNotNull { dependency ->
                dependency.modId.takeIf { it in byId }
            }
        }
        val visiting = mutableSetOf<String>()
        val visited = mutableSetOf<String>()
        val stack = mutableListOf<String>()
        fun visit(node: String) {
            if (node in visiting) {
                val start = stack.indexOf(node).coerceAtLeast(0)
                errors += "dependency cycle: " + (stack.subList(start, stack.size) + node).joinToString(" -> ")
                return
            }
            if (node in visited) return
            visiting += node
            stack += node
            graph[node].orEmpty().forEach(::visit)
            stack.removeAt(stack.lastIndex)
            visiting -= node
            visited += node
        }
        graph.keys.forEach { if (it !in visited) visit(it) }

        val resourceTargets = mutableMapOf<String, Pair<String, String>>()
        packages.forEach { packageEntry ->
            packageEntry.manifest.resources.forEach { resource ->
                val key = resource.target.lowercase()
                val previous = resourceTargets[key]
                if (previous != null && previous.first != packageEntry.manifest.id) {
                    errors += "resource target collision: ${resource.target} is mapped by ${previous.first} and ${packageEntry.manifest.id}"
                } else {
                    resourceTargets[key] = packageEntry.manifest.id to resource.source
                }
            }
        }
        return errors
    }

    fun validateRelativePath(value: String, field: String): String {
        if (value.isEmpty() || '\\' in value || '\u0000' in value || ':' in value) {
            fail("$field must be a non-empty POSIX relative path")
        }
        val parts = value.split('/')
        if (value.startsWith('/') || parts.any { it.isEmpty() || it == "." || it == ".." }) {
            fail("unsafe $field: $value")
        }
        return value
    }

    private fun fail(message: String): Nothing = throw NeoModValidationException(message)
}

package org.neocraft.neomod.core

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.zip.ZipFile

/** Bounded, read-only package inspection. This class never extracts archive entries to disk. */
object NeoModPackageReader {
    data class Limits(
        val maxEntries: Int = 10_000,
        val maxFileBytes: Long = 32L * 1024 * 1024,
        val maxTotalBytes: Long = 128L * 1024 * 1024,
        val maxManifestBytes: Long = 256L * 1024,
        val maxArchiveBytes: Long = 160L * 1024 * 1024,
    )

    data class Inspection(
        val packageEntry: NeoModPackage,
        val fileEntries: Set<String>,
        val totalUncompressedBytes: Long,
    )

    fun inspect(file: File, limits: Limits = Limits()): Inspection {
        if (!file.isFile) fail("package file does not exist or is not a regular file")
        if (!file.name.endsWith(".nmod", ignoreCase = true)) fail("package extension must be .nmod")
        if (limits.maxEntries <= 0 || limits.maxFileBytes <= 0 || limits.maxTotalBytes <= 0 || limits.maxManifestBytes <= 0 || limits.maxArchiveBytes <= 0) {
            fail("package limits must be positive")
        }
        if (file.length() > limits.maxArchiveBytes) fail("compressed archive exceeds ${limits.maxArchiveBytes} byte limit")

        rejectUnixLinksAndSpecialFiles(file)

        ZipFile(file, StandardCharsets.UTF_8).use { zip ->
            val entries = zip.entries()
            val exactNames = mutableSetOf<String>()
            val foldedNames = mutableMapOf<String, String>()
            val files = linkedSetOf<String>()
            var entryCount = 0
            var totalBytes = 0L
            var manifestBytes: ByteArray? = null

            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                entryCount++
                if (entryCount > limits.maxEntries) fail("archive contains more than ${limits.maxEntries} entries")

                val rawName = entry.name
                val isDirectory = entry.isDirectory || rawName.endsWith('/')
                val normalizedName = if (isDirectory) rawName.removeSuffix("/") else rawName
                NeoModValidator.validateRelativePath(normalizedName, "archive entry path")

                if (!exactNames.add(normalizedName)) fail("duplicate archive path: $normalizedName")
                val folded = normalizedName.lowercase()
                val previous = foldedNames.putIfAbsent(folded, normalizedName)
                if (previous != null && previous != normalizedName) {
                    fail("case-insensitive archive path collision: $previous and $normalizedName")
                }

                if (isDirectory) {
                    if (entry.size > 0) fail("directory entry must not contain data: $normalizedName")
                    continue
                }
                files += normalizedName
                val limit = if (normalizedName == "manifest.json") limits.maxManifestBytes else limits.maxFileBytes
                if (entry.size > limit) fail("archive entry exceeds size limit: $normalizedName")

                val output = if (normalizedName == "manifest.json") ByteArrayOutputStream() else null
                var entryBytes = 0L
                zip.getInputStream(entry).use { input ->
                    val buffer = ByteArray(8192)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count == 0) continue
                        entryBytes += count
                        totalBytes += count
                        if (entryBytes > limit) fail("archive entry exceeds size limit: $normalizedName")
                        if (totalBytes > limits.maxTotalBytes) fail("archive exceeds total uncompressed size limit")
                        output?.write(buffer, 0, count)
                    }
                }
                if (entry.size >= 0 && entry.size != entryBytes) fail("archive entry size mismatch: $normalizedName")
                if (normalizedName == "manifest.json") manifestBytes = output!!.toByteArray()
            }

            val manifestData = manifestBytes ?: fail("manifest.json is missing from archive root")
            val manifestText = decodeUtf8Strict(manifestData)
            val manifest = NeoModManifestDecoder.decode(manifestText)
            NeoModValidator.validateManifest(manifest, files)
            return Inspection(
                packageEntry = NeoModPackage(file.absoluteFile.toPath().normalize().toString(), manifest),
                fileEntries = files,
                totalUncompressedBytes = totalBytes,
            )
        }
    }

    private fun decodeUtf8Strict(bytes: ByteArray): String = try {
        StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes)).toString()
    } catch (e: Exception) {
        throw NeoModValidationException("manifest.json must be valid UTF-8")
    }

    /** Reads central-directory Unix mode bits because java.util.zip.ZipEntry does not expose them. */
    private fun rejectUnixLinksAndSpecialFiles(file: File) {
        RandomAccessFile(file, "r").use { raf ->
            val length = raf.length()
            if (length < 22) fail("file is too small to be a ZIP archive")
            val searchStart = (length - 22 - 65_535).coerceAtLeast(0)
            var eocd = -1L
            var pos = length - 22
            while (pos >= searchStart) {
                raf.seek(pos)
                if (readU32(raf) == EOCD_SIGNATURE) {
                    val commentLength = readU16(raf, pos + 20)
                    if (pos + 22 + commentLength == length) {
                        eocd = pos
                        break
                    }
                }
                pos--
            }
            if (eocd < 0) fail("ZIP end-of-central-directory record not found")

            val diskNumber = readU16(raf, eocd + 4)
            val centralDisk = readU16(raf, eocd + 6)
            val entriesOnDisk = readU16(raf, eocd + 8)
            val totalEntries = readU16(raf, eocd + 10)
            val centralSize = readU32(raf, eocd + 12)
            val centralOffset = readU32(raf, eocd + 16)
            if (diskNumber != 0 || centralDisk != 0 || entriesOnDisk != totalEntries) {
                fail("multi-disk ZIP archives are not supported")
            }
            if (totalEntries == 0xFFFF || centralSize == 0xFFFF_FFFFL || centralOffset == 0xFFFF_FFFFL) {
                fail("ZIP64 packages are not supported by NeoMod v1 reader")
            }
            if (centralOffset + centralSize > eocd || centralOffset < 0) fail("invalid ZIP central directory bounds")

            var cursor = centralOffset
            repeat(totalEntries) {
                if (cursor + 46 > centralOffset + centralSize) fail("truncated ZIP central directory")
                raf.seek(cursor)
                if (readU32(raf) != CENTRAL_SIGNATURE) fail("invalid ZIP central directory entry")
                val madeBy = readU16(raf, cursor + 4)
                val platform = madeBy ushr 8
                val externalAttributes = readU32(raf, cursor + 38)
                val nameLength = readU16(raf, cursor + 28)
                val extraLength = readU16(raf, cursor + 30)
                val commentLength = readU16(raf, cursor + 32)
                val nameBytes = ByteArray(nameLength)
                raf.seek(cursor + 46)
                raf.readFully(nameBytes)
                val centralName = decodeUtf8Strict(nameBytes)
                if (platform == UNIX_PLATFORM || platform == MAC_OSX_PLATFORM) {
                    val mode = ((externalAttributes ushr 16) and 0xFFFF).toInt()
                    val type = mode and UNIX_FILE_TYPE_MASK
                    if (type == UNIX_SYMLINK || (type != 0 && type != UNIX_REGULAR && type != UNIX_DIRECTORY)) {
                        fail("symbolic links and special files are not allowed in .nmod packages")
                    }
                    if (type == UNIX_DIRECTORY && !centralName.endsWith('/')) {
                        fail("Unix directory entry must end with '/': $centralName")
                    }
                    if (type == UNIX_REGULAR && centralName.endsWith('/')) {
                        fail("regular file entry must not end with '/': $centralName")
                    }
                }
                cursor += 46L + nameLength + extraLength + commentLength
            }
            if (cursor != centralOffset + centralSize) fail("ZIP central directory size mismatch")
        }
    }

    private fun readU16(raf: RandomAccessFile, offset: Long): Int {
        raf.seek(offset)
        val a = raf.read()
        val b = raf.read()
        if (a < 0 || b < 0) fail("truncated ZIP metadata")
        return a or (b shl 8)
    }

    private fun readU32(raf: RandomAccessFile): Long {
        val a = raf.read()
        val b = raf.read()
        val c = raf.read()
        val d = raf.read()
        if (a < 0 || b < 0 || c < 0 || d < 0) fail("truncated ZIP metadata")
        return (a.toLong() and 0xFF) or
            ((b.toLong() and 0xFF) shl 8) or
            ((c.toLong() and 0xFF) shl 16) or
            ((d.toLong() and 0xFF) shl 24)
    }

    private fun readU32(raf: RandomAccessFile, offset: Long): Long {
        raf.seek(offset)
        return readU32(raf)
    }

    private fun fail(message: String): Nothing = throw NeoModValidationException(message)

    private const val EOCD_SIGNATURE = 0x06054B50L
    private const val CENTRAL_SIGNATURE = 0x02014B50L
    private const val UNIX_PLATFORM = 3
    private const val MAC_OSX_PLATFORM = 19
    private const val UNIX_FILE_TYPE_MASK = 0xF000
    private const val UNIX_REGULAR = 0x8000
    private const val UNIX_DIRECTORY = 0x4000
    private const val UNIX_SYMLINK = 0xA000
}

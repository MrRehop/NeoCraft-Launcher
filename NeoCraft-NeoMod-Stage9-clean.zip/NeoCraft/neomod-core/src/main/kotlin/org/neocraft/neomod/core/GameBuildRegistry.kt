package org.neocraft.neomod.core

/**
 * Platform-neutral identity reported by the Android integration layer.
 * versionName is diagnostic only and is deliberately not used for matching.
 */
data class GameBuildFingerprint(
    val packageName: String,
    val versionCode: Long,
    val versionName: String? = null,
    val signingCertificateSha256: Set<String>? = null,
    val artifactDigests: Map<String, String> = emptyMap(),
)

/** A reviewed identity record. It does not, by itself, grant any mod capabilities. */
data class SupportedGameBuild(
    val buildId: String,
    val packageName: String,
    val versionCode: Long,
    val signingCertificateSha256: Set<String>,
    /** Optional exact digests for selected APK/split artifacts that must be present. */
    val requiredArtifactDigests: Map<String, String> = emptyMap(),
) {
    init {
        require(buildId.isNotBlank()) { "buildId must not be blank" }
        require(packageName.isNotBlank()) { "packageName must not be blank" }
        require(versionCode > 0) { "versionCode must be positive" }
        require(signingCertificateSha256.isNotEmpty()) { "At least one signing certificate digest is required" }
        require(signingCertificateSha256.all(::isSha256)) { "Signing certificate digests must be 64-character SHA-256 hex" }
        require(requiredArtifactDigests.keys.none(String::isBlank)) { "Artifact names must not be blank" }
        require(requiredArtifactDigests.values.all(::isSha256)) { "Artifact digests must be 64-character SHA-256 hex" }
    }
}

sealed interface GameBuildMatch {
    data class Supported(val build: SupportedGameBuild) : GameBuildMatch
    data class Unknown(val reason: String) : GameBuildMatch
}

/**
 * Exact-match registry. Unknown or incomplete evidence never falls back to a
 * version-name match or a partial package/version match.
 */
class GameBuildRegistry(builds: Collection<SupportedGameBuild>) {
    private val byPackageAndVersion: Map<Pair<String, Long>, SupportedGameBuild>

    init {
        val keys = builds.map { it.packageName to it.versionCode }
        require(keys.size == keys.toSet().size) {
            "Registry contains ambiguous duplicate packageName/versionCode records"
        }
        byPackageAndVersion = builds.associateBy { it.packageName to it.versionCode }
    }

    fun match(fingerprint: GameBuildFingerprint): GameBuildMatch {
        if (fingerprint.packageName.isBlank()) {
            return GameBuildMatch.Unknown("Installed package name is missing")
        }
        if (fingerprint.versionCode <= 0) {
            return GameBuildMatch.Unknown("Installed versionCode is missing or invalid")
        }

        val record = byPackageAndVersion[fingerprint.packageName to fingerprint.versionCode]
            ?: return GameBuildMatch.Unknown("No reviewed build record matches packageName and versionCode")

        val observedSigners = fingerprint.signingCertificateSha256
            ?: return GameBuildMatch.Unknown("Signing-certificate identity is unavailable")
        if (observedSigners.isEmpty() || observedSigners.any { !isSha256(it) }) {
            return GameBuildMatch.Unknown("Signing-certificate identity is incomplete or malformed")
        }
        if (observedSigners.map(String::lowercase).toSet() !=
            record.signingCertificateSha256.map(String::lowercase).toSet()
        ) {
            return GameBuildMatch.Unknown("Signing-certificate identity does not match the reviewed build")
        }

        for ((artifactName, expectedDigest) in record.requiredArtifactDigests) {
            val observedDigest = fingerprint.artifactDigests[artifactName]
                ?: return GameBuildMatch.Unknown("Required artifact digest is unavailable: $artifactName")
            if (!isSha256(observedDigest) || !observedDigest.equals(expectedDigest, ignoreCase = true)) {
                return GameBuildMatch.Unknown("Artifact digest does not match: $artifactName")
            }
        }

        return GameBuildMatch.Supported(record)
    }
}

private fun isSha256(value: String): Boolean = value.matches(Regex("^[0-9a-fA-F]{64}$"))

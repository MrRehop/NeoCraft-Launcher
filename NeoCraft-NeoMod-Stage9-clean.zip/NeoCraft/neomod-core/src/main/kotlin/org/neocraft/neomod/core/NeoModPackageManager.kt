package org.neocraft.neomod.core

import java.io.File
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.StandardCopyOption
import java.nio.file.StandardOpenOption
import java.nio.file.attribute.BasicFileAttributes
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipFile

/**
 * Local package store for NeoMod v1.
 *
 * The manager installs package files only. It does not execute scripts, patch Minecraft,
 * or claim runtime isolation. All managed directories are private launcher storage.
 */
class NeoModPackageManager(
    storageDirectory: File,
    private val limits: NeoModPackageReader.Limits = NeoModPackageReader.Limits(),
) {
    data class InstalledMod(
        val id: String,
        val version: String,
        val name: String,
        val directory: File,
        val manifest: NeoModManifest,
    )

    data class Profile(
        val name: String,
        val selections: Map<String, String>,
    )

    private val root: Path = storageDirectory.toPath().toAbsolutePath().normalize()
    private val packagesRoot: Path = root.resolve("packages")
    private val profilesRoot: Path = root.resolve("profiles")
    private val activeProfileFile: Path = root.resolve("active-profile")

    init {
        synchronized(LOCK) {
            ensureDirectory(root)
            ensureDirectory(packagesRoot)
            ensureDirectory(profilesRoot)
            if (!Files.exists(activeProfileFile, LinkOption.NOFOLLOW_LINKS)) {
                writeAtomically(activeProfileFile, DEFAULT_PROFILE + "\n")
            }
            val activeName = readActiveProfileName()
            val activePath = profilePath(activeName)
            if (!Files.exists(activePath, LinkOption.NOFOLLOW_LINKS)) {
                writeProfileAtomically(Profile(activeName, emptyMap()))
            }
        }
    }

    /** Installs one .nmod package into an immutable ID/version directory. */
    @Synchronized
    fun install(packageFile: File): InstalledMod {
        val source = packageFile.toPath().toAbsolutePath().normalize()
        if (!Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(source)) {
            fail("source package must be a regular file")
        }
        if (Files.size(source) > limits.maxArchiveBytes) {
            fail("compressed archive exceeds ${limits.maxArchiveBytes} byte limit")
        }
        val sourceDigestBefore = sha256(source)
        val inspection = NeoModPackageReader.inspect(packageFile, limits)
        if (sha256(source) != sourceDigestBefore) {
            fail("source package changed during inspection")
        }
        val manifest = inspection.packageEntry.manifest
        val idDirectory = packagesRoot.resolve(manifest.id)
        val destination = idDirectory.resolve(manifest.version)
        if (Files.exists(destination, LinkOption.NOFOLLOW_LINKS)) {
            throw NeoModValidationException("package is already installed: ${manifest.id} ${manifest.version}")
        }

        ensureDirectory(idDirectory)
        val staging = packagesRoot.resolve(".staging-${UUID.randomUUID()}")
        ensureDirectory(staging)
        var committed = false
        try {
            extractValidatedArchive(packageFile, staging, inspection.fileEntries)
            val stagedManifestBytes = Files.readAllBytes(staging.resolve("manifest.json"))
            val stagedManifest = NeoModManifestDecoder.decode(decodeUtf8Strict(stagedManifestBytes))
            val stagedFiles = collectRegularFiles(staging)
            NeoModValidator.validateManifest(stagedManifest, stagedFiles)
            if (stagedManifest.id != manifest.id || stagedManifest.version != manifest.version) {
                throw NeoModValidationException("package manifest changed during installation")
            }
            if (sha256(source) != sourceDigestBefore) {
                throw NeoModValidationException("source package changed while it was being installed")
            }
            moveAtomically(staging, destination)
            committed = true
            return InstalledMod(
                id = manifest.id,
                version = manifest.version,
                name = manifest.name,
                directory = destination.toFile(),
                manifest = manifest,
            )
        } finally {
            if (!committed) deleteTreeIfExists(staging)
        }
    }

    /** Lists every installed version. Invalid or tampered installed entries are reported as errors. */
    @Synchronized
    fun listInstalled(): List<InstalledMod> {
        if (!Files.exists(packagesRoot, LinkOption.NOFOLLOW_LINKS)) return emptyList()
        val result = mutableListOf<InstalledMod>()
        Files.newDirectoryStream(packagesRoot).use { idDirs ->
            for (idDir in idDirs) {
                val idName = idDir.fileName.toString()
                if (idName.startsWith(".")) continue
                if (Files.isSymbolicLink(idDir)) fail("symbolic link found in package store: $idName")
                if (!Files.isDirectory(idDir, LinkOption.NOFOLLOW_LINKS)) continue
                Files.newDirectoryStream(idDir).use { versionDirs ->
                    for (versionDir in versionDirs) {
                        if (Files.isSymbolicLink(versionDir)) fail("symbolic link found in installed package: $versionDir")
                        if (!Files.isDirectory(versionDir, LinkOption.NOFOLLOW_LINKS)) continue
                        result += readInstalledPackage(versionDir)
                    }
                }
            }
        }
        return result.sortedWith(compareBy<InstalledMod> { it.id }.thenBy { it.version })
    }

    /** Saves or replaces a profile only if every selected package and dependency is valid. */
    @Synchronized
    fun saveProfile(name: String, selections: Map<String, String>) {
        validateProfileName(name)
        val normalized = selections.toSortedMap()
        val selectedMods = resolveSelection(normalized)
        val errors = NeoModValidator.validateProfile(selectedMods.map { NeoModPackage(it.directory.absolutePath, it.manifest) })
        if (errors.isNotEmpty()) throw NeoModValidationException(errors.joinToString("; "))
        writeProfileAtomically(Profile(name, normalized))
    }

    /** Makes a previously saved profile active after rechecking its installed packages. */
    @Synchronized
    fun activateProfile(name: String) {
        validateProfileName(name)
        val profile = readProfile(name)
        val selectedMods = resolveSelection(profile.selections)
        val errors = NeoModValidator.validateProfile(selectedMods.map { NeoModPackage(it.directory.absolutePath, it.manifest) })
        if (errors.isNotEmpty()) throw NeoModValidationException(errors.joinToString("; "))
        writeAtomically(activeProfileFile, name + "\n")
    }

    @Synchronized
    fun getProfile(name: String): Profile {
        validateProfileName(name)
        return readProfile(name)
    }

    @Synchronized
    fun listProfiles(): List<String> {
        if (!Files.exists(profilesRoot, LinkOption.NOFOLLOW_LINKS)) return emptyList()
        return Files.newDirectoryStream(profilesRoot, "*.profile").use { stream ->
            stream.map { it.fileName.toString().removeSuffix(".profile") }.sorted().toList()
        }
    }

    @Synchronized
    fun activeProfileName(): String = readActiveProfileName()

    @Synchronized
    fun activePackages(): List<InstalledMod> {
        val profile = readProfile(readActiveProfileName())
        return resolveSelection(profile.selections)
    }

    /** Enables or disables one exact package version in the active profile. */
    @Synchronized
    fun setEnabled(id: String, version: String, enabled: Boolean) {
        validateIdentity(id, version)
        val name = readActiveProfileName()
        val selections = readProfile(name).selections.toMutableMap()
        if (enabled) {
            selections[id] = version
        } else {
            val selectedVersion = selections[id]
            if (selectedVersion != null && selectedVersion != version) {
                throw NeoModValidationException("active profile selects $id $selectedVersion, not $version")
            }
            selections.remove(id)
        }
        saveProfile(name, selections)
    }

    @Synchronized
    fun isEnabled(id: String, version: String): Boolean {
        validateIdentity(id, version)
        return readProfile(readActiveProfileName()).selections[id] == version
    }

    /** Refuses to remove a package version while any saved profile still references it. */
    @Synchronized
    fun uninstall(id: String, version: String) {
        validateIdentity(id, version)
        val destination = packagesRoot.resolve(id).resolve(version).normalize()
        if (!destination.startsWith(packagesRoot) || !Files.isDirectory(destination, LinkOption.NOFOLLOW_LINKS)) {
            throw NeoModValidationException("installed package not found: $id $version")
        }
        for (profileName in listProfiles()) {
            val profile = readProfile(profileName)
            if (profile.selections[id] == version) {
                throw NeoModValidationException("package is referenced by profile '$profileName'; update that profile before uninstalling")
            }
        }

        val trash = packagesRoot.resolve(".trash-${UUID.randomUUID()}")
        moveAtomically(destination, trash)
        try {
            deleteTreeIfExists(trash)
            val idDirectory = packagesRoot.resolve(id)
            if (Files.isDirectory(idDirectory, LinkOption.NOFOLLOW_LINKS)) {
                Files.newDirectoryStream(idDirectory).use { children ->
                    if (!children.iterator().hasNext()) Files.deleteIfExists(idDirectory)
                }
            }
        } catch (failure: Throwable) {
            throw IOException("package was detached from the installed store, but cleanup failed; leftover data: $trash", failure)
        }
    }

    private fun resolveSelection(selections: Map<String, String>): List<InstalledMod> {
        val installed = listInstalled().associateBy { it.id to it.version }
        val selected = selections.map { (id, version) ->
            validateIdentity(id, version)
            val mod = installed[id to version]
                ?: throw NeoModValidationException("selected package is not installed: $id $version")
            mod
        }
        return selected
    }

    private fun readInstalledPackage(directory: Path): InstalledMod {
        val normalizedDirectory = directory.toAbsolutePath().normalize()
        val manifestFile = normalizedDirectory.resolve("manifest.json")
        if (!Files.isRegularFile(manifestFile, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(manifestFile)) {
            fail("installed package has no regular root manifest: $directory")
        }
        if (Files.size(manifestFile) > limits.maxManifestBytes) {
            fail("installed manifest exceeds ${limits.maxManifestBytes} byte limit: $directory")
        }
        val manifest = NeoModManifestDecoder.decode(decodeUtf8Strict(Files.readAllBytes(manifestFile)))
        val idDirectory = directory.parent.fileName.toString()
        val versionDirectory = directory.fileName.toString()
        if (manifest.id != idDirectory || manifest.version != versionDirectory) {
            fail("installed package identity does not match its storage path: $directory")
        }
        val files = collectRegularFiles(normalizedDirectory)
        NeoModValidator.validateManifest(manifest, files)
        return InstalledMod(manifest.id, manifest.version, manifest.name, directory.toFile(), manifest)
    }

    private fun extractValidatedArchive(packageFile: File, staging: Path, expectedFiles: Set<String>) {
        val extracted = linkedSetOf<String>()
        var totalBytes = 0L
        ZipFile(packageFile, StandardCharsets.UTF_8).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val rawName = entry.name
                val directoryEntry = entry.isDirectory || rawName.endsWith('/')
                val relative = if (directoryEntry) rawName.removeSuffix("/") else rawName
                NeoModValidator.validateRelativePath(relative, "archive entry path")
                val output = safeResolve(staging, relative)
                if (directoryEntry) {
                    ensureDirectory(output)
                    continue
                }
                if (!extracted.add(relative)) fail("duplicate archive path during extraction: $relative")
                if (relative !in expectedFiles) fail("archive changed after inspection: unexpected entry $relative")
                ensureDirectory(output.parent)
                var entryBytes = 0L
                val maxEntry = if (relative == "manifest.json") limits.maxManifestBytes else limits.maxFileBytes
                zip.getInputStream(entry).use { input ->
                    Files.newOutputStream(output, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE).use { out ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (count == 0) continue
                            entryBytes += count
                            totalBytes += count
                            if (entryBytes > maxEntry) fail("archive entry exceeds size limit during extraction: $relative")
                            if (totalBytes > limits.maxTotalBytes) fail("archive exceeds total size limit during extraction")
                            out.write(buffer, 0, count)
                        }
                    }
                }
                if (entry.size >= 0 && entry.size != entryBytes) fail("archive entry size mismatch during extraction: $relative")
            }
        }
        if (extracted != expectedFiles) fail("archive entries changed after inspection")
    }

    private fun collectRegularFiles(directory: Path): Set<String> {
        val result = linkedSetOf<String>()
        Files.walkFileTree(directory, object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                if (attrs.isSymbolicLink || Files.isSymbolicLink(file) || !attrs.isRegularFile) {
                    fail("installed package contains a non-regular file: $file")
                }
                result += directory.relativize(file).joinToString("/") { it.toString() }
                return FileVisitResult.CONTINUE
            }
        })
        return result
    }

    private fun readProfile(name: String): Profile {
        val path = profilePath(name)
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(path)) {
            throw NeoModValidationException("profile not found: $name")
        }
        val lines = Files.readAllLines(path, StandardCharsets.UTF_8)
        if (lines.firstOrNull() != PROFILE_HEADER) fail("invalid profile format: $name")
        val selections = linkedMapOf<String, String>()
        lines.drop(1).forEachIndexed { index, line ->
            if (line.isBlank()) return@forEachIndexed
            val separator = line.indexOf('\t')
            if (separator <= 0 || separator == line.lastIndex) fail("invalid profile entry at line ${index + 2}")
            val id = line.substring(0, separator)
            val version = line.substring(separator + 1)
            validateIdentity(id, version)
            if (selections.putIfAbsent(id, version) != null) fail("duplicate mod ID in profile: $id")
        }
        return Profile(name, selections)
    }

    private fun writeProfileAtomically(profile: Profile) {
        val content = buildString {
            append(PROFILE_HEADER).append('\n')
            profile.selections.toSortedMap().forEach { (id, version) ->
                validateIdentity(id, version)
                append(id).append('\t').append(version).append('\n')
            }
        }
        writeAtomically(profilePath(profile.name), content)
    }

    private fun readActiveProfileName(): String {
        if (!Files.isRegularFile(activeProfileFile, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(activeProfileFile)) {
            fail("active profile pointer is missing or invalid")
        }
        val name = String(Files.readAllBytes(activeProfileFile), StandardCharsets.UTF_8).trim()
        validateProfileName(name)
        return name
    }

    private fun profilePath(name: String): Path = profilesRoot.resolve("$name.profile")

    private fun writeAtomically(destination: Path, content: String) {
        ensureDirectory(destination.parent)
        val temporary = destination.parent.resolve(".${destination.fileName}.${UUID.randomUUID()}.tmp")
        try {
            Files.newOutputStream(
                temporary,
                StandardOpenOption.CREATE_NEW,
                StandardOpenOption.WRITE,
            ).use { output ->
                output.write(content.toByteArray(StandardCharsets.UTF_8))
            }
            moveAtomically(temporary, destination, replace = true)
        } finally {
            Files.deleteIfExists(temporary)
        }
    }

    private fun moveAtomically(source: Path, destination: Path, replace: Boolean = false) {
        val options = if (replace) {
            arrayOf(StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } else {
            arrayOf(StandardCopyOption.ATOMIC_MOVE)
        }
        try {
            Files.move(source, destination, *options)
        } catch (e: AtomicMoveNotSupportedException) {
            throw IOException("storage filesystem does not support required atomic moves", e)
        }
    }

    private fun ensureDirectory(path: Path) {
        if (Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
            if (Files.isSymbolicLink(path) || !Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) {
                fail("managed storage path is not a real directory: $path")
            }
        } else {
            Files.createDirectories(path)
            if (Files.isSymbolicLink(path) || !Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) {
                fail("could not create a safe managed directory: $path")
            }
        }
    }

    private fun safeResolve(base: Path, relative: String): Path {
        val result = base.resolve(relative).normalize()
        if (!result.startsWith(base.normalize())) fail("archive path escapes staging directory: $relative")
        return result
    }

    private fun sha256(path: Path): String {
        val digest = MessageDigest.getInstance("SHA-256")
        Files.newInputStream(path).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count > 0) digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun deleteTreeIfExists(path: Path) {
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return
        if (Files.isSymbolicLink(path)) fail("refusing to recursively delete a symbolic link: $path")
        Files.walkFileTree(path, object : SimpleFileVisitor<Path>() {
            override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                if (Files.isSymbolicLink(file)) fail("refusing to delete a tree containing a symbolic link: $file")
                Files.delete(file)
                return FileVisitResult.CONTINUE
            }

            override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                if (exc != null) throw exc
                Files.delete(dir)
                return FileVisitResult.CONTINUE
            }
        })
    }

    private fun validateIdentity(id: String, version: String) {
        if (!ID_PATTERN.matches(id)) fail("invalid package ID: $id")
        NeoModValidator.parseVersion(version)
    }

    private fun validateProfileName(name: String) {
        if (!PROFILE_PATTERN.matches(name) || name == "." || name == "..") {
            fail("profile name must contain 1..48 letters, digits, dot, underscore or hyphen")
        }
    }

    private fun decodeUtf8Strict(bytes: ByteArray): String = try {
        StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
            .decode(java.nio.ByteBuffer.wrap(bytes)).toString()
    } catch (e: Exception) {
        throw NeoModValidationException("installed manifest.json must be valid UTF-8")
    }

    private fun fail(message: String): Nothing = throw NeoModValidationException(message)

    companion object {
        private val LOCK = Any()
        private val ID_PATTERN = Regex("^[a-z0-9]+(?:[.-][a-z0-9]+)*\\.[a-z0-9]+(?:[.-][a-z0-9]+)*$")
        private val PROFILE_PATTERN = Regex("^[A-Za-z0-9._-]{1,48}$")
        private const val DEFAULT_PROFILE = "default"
        private const val PROFILE_HEADER = "NEOMOD_PROFILE_V1"
    }
}

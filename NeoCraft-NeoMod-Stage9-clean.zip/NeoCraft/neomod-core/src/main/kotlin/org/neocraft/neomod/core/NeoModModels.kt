package org.neocraft.neomod.core

data class NeoModDependency(
    val modId: String,
    val versionConstraint: String,
    val optional: Boolean = false,
)

data class NeoModResource(
    val source: String,
    val target: String,
    val capability: String,
)

data class NeoModManifest(
    val formatVersion: Int,
    val id: String,
    val name: String,
    val version: String,
    val gameId: String,
    val gameVersions: List<String>,
    val dependencies: List<NeoModDependency> = emptyList(),
    val conflicts: List<String> = emptyList(),
    val capabilities: Set<String> = emptySet(),
    val resources: List<NeoModResource> = emptyList(),
    val author: String? = null,
    val description: String? = null,
    val entrypoint: String? = null,
)

data class NeoModPackage(
    val path: String,
    val manifest: NeoModManifest,
)

class NeoModValidationException(message: String) : IllegalArgumentException(message)

package org.neocraft.neomod.core

private const val MOD_A = "org.neocraft.alpha"
private const val MOD_B = "org.neocraft.beta"

private fun manifest(
    id: String = MOD_A,
    version: String = "1.2.0",
    dependencies: List<NeoModDependency> = emptyList(),
    conflicts: List<String> = emptyList(),
    resources: List<NeoModResource> = listOf(NeoModResource("assets/a.bin", "textures/a.bin", "textures")),
    capabilities: Set<String> = setOf("textures"),
) = NeoModManifest(
    formatVersion = 1,
    id = id,
    name = id.substringAfterLast('.'),
    version = version,
    gameId = "minecraft-bedrock",
    gameVersions = listOf("1.21.x"),
    dependencies = dependencies,
    conflicts = conflicts,
    capabilities = capabilities,
    resources = resources,
)

private fun pkg(m: NeoModManifest, path: String = "${m.id}.nmod") = NeoModPackage(path, m)

fun main() {
    val tests = listOf<Pair<String, () -> Unit>>(
        "valid manifest accepted" to {
            NeoModValidator.validateManifest(manifest(), setOf("assets/a.bin"))
        },
        "reverse-DNS ID enforced" to {
            val error = runCatching { NeoModValidator.validateManifest(manifest(id = "Bad_ID"), setOf("assets/a.bin")) }.exceptionOrNull()
            check(error is NeoModValidationException)
        },
        "unsafe relative path rejected" to {
            val error = runCatching { NeoModValidator.validateRelativePath("../outside", "resource.source") }.exceptionOrNull()
            check(error is NeoModValidationException)
        },
        "missing resource rejected" to {
            val error = runCatching { NeoModValidator.validateManifest(manifest(), emptySet()) }.exceptionOrNull()
            check(error?.message?.contains("does not exist") == true)
        },
        "required dependency missing" to {
            val errors = NeoModValidator.validateProfile(listOf(pkg(manifest(dependencies = listOf(NeoModDependency(MOD_B, ">=1.0.0"))))))
            check(errors.any { it.contains("missing dependency") })
        },
        "optional dependency may be absent" to {
            val errors = NeoModValidator.validateProfile(listOf(pkg(manifest(dependencies = listOf(NeoModDependency(MOD_B, ">=1.0.0", optional = true))))))
            check(errors.none { it.contains("missing dependency") })
        },
        "dependency version mismatch detected" to {
            val consumer = pkg(manifest(dependencies = listOf(NeoModDependency(MOD_B, ">=2.0.0,<3.0.0"))))
            val provider = pkg(manifest(id = MOD_B, version = "1.5.0"))
            check(NeoModValidator.validateProfile(listOf(consumer, provider)).any { it.contains("version mismatch") })
        },
        "declared conflict detected" to {
            val a = pkg(manifest(conflicts = listOf(MOD_B)))
            val b = pkg(manifest(id = MOD_B))
            check(NeoModValidator.validateProfile(listOf(a, b)).any { it.contains("declared conflict") })
        },
        "dependency cycle detected" to {
            val a = pkg(manifest(dependencies = listOf(NeoModDependency(MOD_B, ">=1.0.0"))))
            val b = pkg(manifest(id = MOD_B, dependencies = listOf(NeoModDependency(MOD_A, ">=1.0.0"))))
            check(NeoModValidator.validateProfile(listOf(a, b)).any { it.contains("dependency cycle") })
        },
        "cross-package resource collision detected case-insensitively" to {
            val a = pkg(manifest())
            val b = pkg(manifest(id = MOD_B, resources = listOf(NeoModResource("assets/a.bin", "TEXTURES/A.BIN", "textures"))))
            check(NeoModValidator.validateProfile(listOf(a, b)).any { it.contains("resource target collision") })
        },
        "invalid dependency constraint rejected even when optional" to {
            val error = runCatching {
                NeoModValidator.validateManifest(
                    manifest(dependencies = listOf(NeoModDependency(MOD_B, ">=1.0.0,not-a-range", optional = true))),
                    setOf("assets/a.bin"),
                )
            }.exceptionOrNull()
            check(error?.message?.contains("unsupported dependency constraint") == true)
        },
        "entrypoint requires scripts capability" to {
            val error = runCatching {
                NeoModValidator.validateManifest(manifest().copy(entrypoint = "scripts/main.js"), setOf("assets/a.bin", "scripts/main.js"))
            }.exceptionOrNull()
            check(error?.message?.contains("requires the scripts capability") == true)
        },
        "duplicate IDs detected" to {
            val a = pkg(manifest(), "a.nmod")
            val b = pkg(manifest(), "b.nmod")
            check(NeoModValidator.validateProfile(listOf(a, b)).any { it.contains("duplicate mod ID") })
        },
        "version range comparison works" to {
            check(NeoModValidator.isVersionSatisfied("1.5.0", ">=1.2.0,<2.0.0"))
            check(!NeoModValidator.isVersionSatisfied("2.0.0", ">=1.2.0,<2.0.0"))
        },
    )

    var passed = 0
    tests.forEach { (name, test) ->
        try {
            test()
            println("PASS: $name")
            passed++
        } catch (t: Throwable) {
            System.err.println("FAIL: $name — ${t.message}")
            throw t
        }
    }
    println("CORE RESULT: $passed/${tests.size} tests passed")
    val (packageReaderPassed, packageReaderTotal) = runPackageReaderSelfTests()
    val (managerPassed, managerTotal) = runPackageManagerSelfTests()
    val (buildIdentityPassed, buildIdentityTotal) = runGameBuildIdentitySelfTests()
    println("ALL JVM SELF-TESTS: ${passed + packageReaderPassed + managerPassed + buildIdentityPassed}/${tests.size + packageReaderTotal + managerTotal + buildIdentityTotal} passed")
}

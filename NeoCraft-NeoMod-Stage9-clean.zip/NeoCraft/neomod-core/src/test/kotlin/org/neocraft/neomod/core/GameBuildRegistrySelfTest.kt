package org.neocraft.neomod.core

private const val TEST_CERT = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
private const val OTHER_CERT = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
private const val BASE_APK_DIGEST = "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"

private fun testBuild() = SupportedGameBuild(
    buildId = "test-build-26.13.1",
    packageName = "org.example.minecraft.patched",
    versionCode = 12345L,
    signingCertificateSha256 = setOf(TEST_CERT),
    requiredArtifactDigests = mapOf("base.apk" to BASE_APK_DIGEST),
)

fun runGameBuildIdentitySelfTests(): Pair<Int, Int> {
    val record = testBuild()
    val registry = GameBuildRegistry(listOf(record))
    val valid = GameBuildFingerprint(
        packageName = record.packageName,
        versionCode = record.versionCode,
        versionName = "1.26.13.1",
        signingCertificateSha256 = setOf(TEST_CERT),
        artifactDigests = mapOf("base.apk" to BASE_APK_DIGEST),
    )

    val tests = listOf<Pair<String, () -> Unit>>(
        "exact reviewed build is recognized" to {
            check(registry.match(valid) == GameBuildMatch.Supported(record))
        },
        "version name is diagnostic and does not override exact identity" to {
            check(registry.match(valid.copy(versionName = "patched-label")) == GameBuildMatch.Supported(record))
        },
        "unknown package is not guessed from version" to {
            val result = registry.match(valid.copy(packageName = "org.example.other"))
            check(result is GameBuildMatch.Unknown)
        },
        "different version code is rejected" to {
            val result = registry.match(valid.copy(versionCode = valid.versionCode + 1))
            check(result is GameBuildMatch.Unknown)
        },
        "different signing certificate is rejected" to {
            val result = registry.match(valid.copy(signingCertificateSha256 = setOf(OTHER_CERT)))
            check(result is GameBuildMatch.Unknown)
        },
        "missing signing certificate is rejected" to {
            val result = registry.match(valid.copy(signingCertificateSha256 = null))
            check(result is GameBuildMatch.Unknown)
        },
        "missing required artifact digest is rejected" to {
            val result = registry.match(valid.copy(artifactDigests = emptyMap()))
            check(result is GameBuildMatch.Unknown)
        },
        "mismatched artifact digest is rejected" to {
            val result = registry.match(valid.copy(artifactDigests = mapOf("base.apk" to OTHER_CERT)))
            check(result is GameBuildMatch.Unknown)
        },
        "ambiguous registry records are rejected" to {
            val error = runCatching { GameBuildRegistry(listOf(record, record.copy(buildId = "duplicate"))) }.exceptionOrNull()
            check(error is IllegalArgumentException)
        },
    )

    var passed = 0
    tests.forEach { (name, test) ->
        try {
            test()
            println("PASS: $name")
            passed++
        } catch (t: Throwable) {
            System.err.println("FAIL: $name — ${t.message}")
            throw t
        }
    }
    println("GAME BUILD IDENTITY RESULT: $passed/${tests.size} tests passed")
    return passed to tests.size
}

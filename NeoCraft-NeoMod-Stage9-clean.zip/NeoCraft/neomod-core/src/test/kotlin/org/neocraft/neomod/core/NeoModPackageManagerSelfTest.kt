package org.neocraft.neomod.core

import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private const val MANAGED_MOD_ID = "org.neocraft.managed"
private const val MANAGED_DEP_ID = "org.neocraft.dependency"

private fun managerManifest(
    id: String = MANAGED_MOD_ID,
    version: String = "1.0.0",
    dependency: String? = null,
): String = buildString {
    append("""{
      "format_version": 1,
      "id": "$id",
      "name": "${id.substringAfterLast('.')}",
      "version": "$version",
      "game": { "id": "minecraft-bedrock", "versions": ["1.21.x"] },
      "dependencies": [""")
    if (dependency != null) {
        append("""{ "id": "$dependency", "version": ">=1.0.0" }""")
    }
    append("""],
      "conflicts": [],
      "capabilities": ["textures"],
      "resources": [
        { "source": "assets/texture.bin", "target": "textures/managed.bin", "capability": "textures" }
      ],
      "entrypoint": null
    }""")
}

private fun makeManagerPackage(
    id: String = MANAGED_MOD_ID,
    version: String = "1.0.0",
    dependency: String? = null,
): File {
    val file = Files.createTempFile("neomod-manager-", ".nmod").toFile()
    ZipOutputStream(file.outputStream()).use { zip ->
        val manifest = managerManifest(id, version, dependency).toByteArray(StandardCharsets.UTF_8)
        zip.putNextEntry(ZipEntry("manifest.json"))
        zip.write(manifest)
        zip.closeEntry()
        zip.putNextEntry(ZipEntry("assets/texture.bin"))
        zip.write(byteArrayOf(1, 2, 3, 4))
        zip.closeEntry()
    }
    file.deleteOnExit()
    return file
}

fun runPackageManagerSelfTests(): Pair<Int, Int> {
    val tests = listOf<Pair<String, () -> Unit>>(
        "valid package installs into ID/version namespace" to {
            val root = Files.createTempDirectory("neomod-store-install-").toFile()
            val packageFile = makeManagerPackage()
            val manager = NeoModPackageManager(root)
            val installed = manager.install(packageFile)
            check(installed.id == MANAGED_MOD_ID)
            check(installed.version == "1.0.0")
            check(File(installed.directory, "assets/texture.bin").readBytes().contentEquals(byteArrayOf(1, 2, 3, 4)))
            check(manager.listInstalled().size == 1)
        },
        "duplicate package version rejected without damaging installed copy" to {
            val root = Files.createTempDirectory("neomod-store-duplicate-").toFile()
            val packageFile = makeManagerPackage()
            val manager = NeoModPackageManager(root)
            val first = manager.install(packageFile)
            val error = runCatching { manager.install(packageFile) }.exceptionOrNull()
            check(error is NeoModValidationException && error.message!!.contains("already installed"))
            check(File(first.directory, "manifest.json").isFile)
            check(manager.listInstalled().size == 1)
        },
        "multiple versions of the same ID can coexist" to {
            val root = Files.createTempDirectory("neomod-store-versions-").toFile()
            val manager = NeoModPackageManager(root)
            manager.install(makeManagerPackage(version = "1.0.0"))
            manager.install(makeManagerPackage(version = "1.1.0"))
            check(manager.listInstalled().map { it.version }.toSet() == setOf("1.0.0", "1.1.0"))
        },
        "valid profile can be saved activated and reopened" to {
            val root = Files.createTempDirectory("neomod-store-profile-").toFile()
            val manager = NeoModPackageManager(root)
            manager.install(makeManagerPackage())
            manager.saveProfile("creative", mapOf(MANAGED_MOD_ID to "1.0.0"))
            manager.activateProfile("creative")
            check(manager.activeProfileName() == "creative")
            check(manager.activePackages().single().id == MANAGED_MOD_ID)
            val reopened = NeoModPackageManager(root)
            check(reopened.activeProfileName() == "creative")
            check(reopened.activePackages().single().version == "1.0.0")
        },
        "active profile supports independent enable and disable" to {
            val root = Files.createTempDirectory("neomod-store-toggle-").toFile()
            val manager = NeoModPackageManager(root)
            manager.install(makeManagerPackage())
            manager.setEnabled(MANAGED_MOD_ID, "1.0.0", true)
            check(manager.isEnabled(MANAGED_MOD_ID, "1.0.0"))
            check(manager.activePackages().single().id == MANAGED_MOD_ID)
            manager.setEnabled(MANAGED_MOD_ID, "1.0.0", false)
            check(!manager.isEnabled(MANAGED_MOD_ID, "1.0.0"))
            check(manager.activePackages().isEmpty())
        },
        "enabling a package with missing dependency is rejected" to {
            val root = Files.createTempDirectory("neomod-store-toggle-dependency-").toFile()
            val manager = NeoModPackageManager(root)
            manager.install(makeManagerPackage(dependency = MANAGED_DEP_ID))
            val error = runCatching { manager.setEnabled(MANAGED_MOD_ID, "1.0.0", true) }.exceptionOrNull()
            check(error is NeoModValidationException && error.message!!.contains("missing dependency"))
            check(!manager.isEnabled(MANAGED_MOD_ID, "1.0.0"))
        },
        "profile with missing required dependency is rejected" to {
            val root = Files.createTempDirectory("neomod-store-dependency-").toFile()
            val manager = NeoModPackageManager(root)
            manager.install(makeManagerPackage(dependency = MANAGED_DEP_ID))
            val error = runCatching {
                manager.saveProfile("broken", mapOf(MANAGED_MOD_ID to "1.0.0"))
            }.exceptionOrNull()
            check(error is NeoModValidationException && error.message!!.contains("missing dependency"))
            check("broken" !in manager.listProfiles())
        },
        "uninstall is blocked while a saved profile references package" to {
            val root = Files.createTempDirectory("neomod-store-uninstall-guard-").toFile()
            val manager = NeoModPackageManager(root)
            manager.install(makeManagerPackage())
            manager.saveProfile("used", mapOf(MANAGED_MOD_ID to "1.0.0"))
            val error = runCatching { manager.uninstall(MANAGED_MOD_ID, "1.0.0") }.exceptionOrNull()
            check(error is NeoModValidationException && error.message!!.contains("referenced by profile"))
            check(manager.listInstalled().size == 1)
        },
        "package can be uninstalled after all profiles stop referencing it" to {
            val root = Files.createTempDirectory("neomod-store-uninstall-").toFile()
            val manager = NeoModPackageManager(root)
            manager.install(makeManagerPackage())
            manager.saveProfile("used", mapOf(MANAGED_MOD_ID to "1.0.0"))
            manager.saveProfile("used", emptyMap())
            manager.uninstall(MANAGED_MOD_ID, "1.0.0")
            check(manager.listInstalled().isEmpty())
        },
        "invalid profile names rejected" to {
            val root = Files.createTempDirectory("neomod-store-profile-name-").toFile()
            val manager = NeoModPackageManager(root)
            val error = runCatching { manager.saveProfile("../escape", emptyMap()) }.exceptionOrNull()
            check(error is NeoModValidationException)
        },
        "uninstall of absent package rejected" to {
            val root = Files.createTempDirectory("neomod-store-absent-").toFile()
            val manager = NeoModPackageManager(root)
            val error = runCatching { manager.uninstall(MANAGED_MOD_ID, "1.0.0") }.exceptionOrNull()
            check(error is NeoModValidationException && error.message!!.contains("not found"))
        },
    )

    var passed = 0
    tests.forEach { (name, test) ->
        try {
            test()
            println("PASS: $name")
            passed++
        } catch (t: Throwable) {
            System.err.println("FAIL: $name — ${t.message}")
            throw t
        }
    }
    println("PACKAGE MANAGER RESULT: $passed/${tests.size} tests passed")
    return passed to tests.size
}

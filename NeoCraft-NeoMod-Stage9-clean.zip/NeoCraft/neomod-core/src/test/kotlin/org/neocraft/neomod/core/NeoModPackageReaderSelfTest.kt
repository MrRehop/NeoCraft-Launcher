package org.neocraft.neomod.core

import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private const val VALID_MANIFEST = """{
  "format_version": 1,
  "id": "org.neocraft.hello",
  "name": "Hello NeoMod",
  "version": "1.0.0",
  "game": { "id": "minecraft-bedrock", "versions": ["1.21.x"] },
  "dependencies": [],
  "conflicts": [],
  "capabilities": ["textures"],
  "resources": [
    { "source": "assets/textures/hello.png", "target": "textures/blocks/hello.png", "capability": "textures" }
  ],
  "entrypoint": null
}"""

private fun makeNmod(entries: List<Pair<String, ByteArray>>): File {
    val file = Files.createTempFile("neomod-test-", ".nmod").toFile()
    ZipOutputStream(file.outputStream()).use { zip ->
        entries.forEach { (name, bytes) ->
            zip.putNextEntry(ZipEntry(name))
            zip.write(bytes)
            zip.closeEntry()
        }
    }
    file.deleteOnExit()
    return file
}

private fun text(value: String) = value.toByteArray(StandardCharsets.UTF_8)

private fun markFirstCentralEntryAsUnixSymlink(file: File) {
    val bytes = Files.readAllBytes(file.toPath())
    val signature = byteArrayOf(0x50, 0x4B, 0x01, 0x02)
    val offset = (0..bytes.size - signature.size).firstOrNull { start ->
        signature.indices.all { i -> bytes[start + i] == signature[i] }
    } ?: error("central directory signature not found in test ZIP")
    // version-made-by platform = Unix; external attributes contain S_IFLNK | 0777.
    bytes[offset + 5] = 3
    bytes[offset + 38] = 0
    bytes[offset + 39] = 0
    bytes[offset + 40] = 0xFF.toByte()
    bytes[offset + 41] = 0xA1.toByte()
    Files.write(file.toPath(), bytes)
}

fun runPackageReaderSelfTests(): Pair<Int, Int> {
    val payload = text("png-placeholder")
    val tests = listOf<Pair<String, () -> Unit>>(
        "valid nmod package decoded and validated" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "assets/textures/hello.png" to payload))
            val result = NeoModPackageReader.inspect(file)
            check(result.packageEntry.manifest.id == "org.neocraft.hello")
            check("assets/textures/hello.png" in result.fileEntries)
            check(result.totalUncompressedBytes == text(VALID_MANIFEST).size + payload.size.toLong())
        },
        "missing root manifest rejected" to {
            val file = makeNmod(listOf("readme.txt" to text("no manifest")))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("manifest.json is missing") == true)
        },
        "path traversal rejected before install" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "../escape.txt" to payload))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull() is NeoModValidationException)
        },
        "case-only archive path collision rejected" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "assets/a.png" to payload, "ASSETS/A.PNG" to payload))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("case-insensitive") == true)
        },
        "duplicate JSON keys rejected" to {
            val duplicate = VALID_MANIFEST.replace("\"name\": \"Hello NeoMod\"", "\"name\": \"Hello NeoMod\", \"name\": \"Shadow\"")
            val file = makeNmod(listOf("manifest.json" to text(duplicate), "assets/textures/hello.png" to payload))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("duplicate JSON object key") == true)
        },
        "malformed UTF-8 rejected" to {
            val invalidUtf8 = byteArrayOf(0xC3.toByte(), 0x28)
            val file = makeNmod(listOf("manifest.json" to invalidUtf8))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("valid UTF-8") == true)
        },
        "missing declared resource rejected" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST)))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("resource source does not exist") == true)
        },
        "per-file decompressed size limit enforced" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "assets/textures/hello.png" to ByteArray(128)))
            val limits = NeoModPackageReader.Limits(maxFileBytes = 64)
            check(runCatching { NeoModPackageReader.inspect(file, limits) }.exceptionOrNull()?.message?.contains("size limit") == true)
        },
        "total decompressed size limit enforced" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "assets/textures/hello.png" to ByteArray(128)))
            val limits = NeoModPackageReader.Limits(maxTotalBytes = 100)
            check(runCatching { NeoModPackageReader.inspect(file, limits) }.exceptionOrNull()?.message?.contains("total uncompressed") == true)
        },
        "unknown v1 manifest fields rejected" to {
            val extended = VALID_MANIFEST.replace("\"entrypoint\": null", "\"entrypoint\": null, \"mystery\": true")
            val file = makeNmod(listOf("manifest.json" to text(extended), "assets/textures/hello.png" to payload))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("unknown manifest field") == true)
        },
        "archive entry-count limit enforced" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "assets/textures/hello.png" to payload))
            val limits = NeoModPackageReader.Limits(maxEntries = 1)
            check(runCatching { NeoModPackageReader.inspect(file, limits) }.exceptionOrNull()?.message?.contains("more than 1 entries") == true)
        },
        "manifest size limit enforced" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "assets/textures/hello.png" to payload))
            val limits = NeoModPackageReader.Limits(maxManifestBytes = 64)
            check(runCatching { NeoModPackageReader.inspect(file, limits) }.exceptionOrNull()?.message?.contains("size limit") == true)
        },
        "duplicate capabilities rejected" to {
            val duplicate = VALID_MANIFEST.replace("[\"textures\"]", "[\"textures\", \"textures\"]")
            val file = makeNmod(listOf("manifest.json" to text(duplicate), "assets/textures/hello.png" to payload))
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("duplicate values") == true)
        },
        "Unix symbolic link entry rejected" to {
            val file = makeNmod(listOf("manifest.json" to text(VALID_MANIFEST), "assets/textures/hello.png" to payload))
            markFirstCentralEntryAsUnixSymlink(file)
            check(runCatching { NeoModPackageReader.inspect(file) }.exceptionOrNull()?.message?.contains("symbolic links") == true)
        },
    )

    var passed = 0
    tests.forEach { (name, test) ->
        try {
            test()
            println("PASS: $name")
            passed++
        } catch (t: Throwable) {
            System.err.println("FAIL: $name — ${t.message}")
            throw t
        }
    }
    println("PACKAGE READER RESULT: $passed/${tests.size} tests passed")
    return passed to tests.size
}

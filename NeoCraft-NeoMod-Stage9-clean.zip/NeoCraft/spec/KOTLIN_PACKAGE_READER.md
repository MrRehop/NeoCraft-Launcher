# NeoMod Kotlin Package Reader — Stage 3

## Implemented

`NeoModPackageReader.inspect(File)` performs read-only inspection of a `.nmod` package:

1. Checks the file and `.nmod` extension.
2. Reads ZIP central-directory metadata and rejects Unix symbolic links and special file types.
3. Rejects multi-disk and ZIP64 archives in format v1.
4. Checks archive entry count, path safety, exact duplicates and case-insensitive path collisions.
5. Streams every regular entry to validate decompressed sizes and ZIP CRCs without extracting files.
6. Enforces archive, per-file, total uncompressed and manifest size limits.
7. Decodes `manifest.json` as strict UTF-8 and parses JSON without a third-party dependency.
8. Rejects duplicate JSON keys and unknown format-v1 fields.
9. Converts the manifest to the typed Kotlin model and calls `NeoModValidator.validateManifest`.

Default limits:

| Limit | Value |
|---|---:|
| Compressed archive | 160 MiB |
| ZIP entries, including directories | 10,000 |
| One non-manifest file, uncompressed | 32 MiB |
| Total uncompressed file content | 128 MiB |
| `manifest.json` | 256 KiB |

## API example

```kotlin
val inspection = NeoModPackageReader.inspect(File("/path/to/mod.nmod"))
val manifest = inspection.packageEntry.manifest
println("${manifest.id} ${manifest.version}")
```

## Security boundary

- The reader does not extract files or install packages.
- ZIP entry data is streamed and discarded after validation, except the bounded manifest.
- ZIP64 and multi-disk archives are rejected in v1.
- A package that passes inspection is structurally valid according to the current v1 rules; it is not authenticated or trusted. Package signatures and publisher trust are not implemented.
- `scripts` and `entrypoint` remain metadata only. No code is executed.
- This JVM implementation has been tested on JDK 21 with Kotlin compiler 1.9.0. Android runtime/API compatibility has not yet been verified.

> Historical record for Stage 7. Stage 8 later added `:app` and `MainActivity`; Stage 9 corrected the minimum SDK to 26. Do not use the Stage 7 `minSdk = 23` value as the current project setting.

# Android module wiring — Stage 7

## What changed

- Registered `:android-integration` in `settings.gradle.kts`.
- Added Android Gradle Plugin `8.6.1` and Kotlin Android plugin `1.9.0` at the root.
- Added an Android library module build file with namespace `org.neocraft.neomod.android`, `compileSdk = 35`, `minSdk = 23`, and Java/Kotlin 17 bytecode targets.
- Added a module dependency on `:neomod-core`.
- Moved the package-visibility declaration into the module's real `src/main/AndroidManifest.xml`, where Android manifest merging can consume it.

## Why this is an Android library, not an APK

This stage wires the platform adapter into a buildable Android module while keeping the platform-neutral core separate. It intentionally does not create an application module, launcher Activity, UI, or APK yet. The next stage can add `:app` and depend on this library without moving core code into Android.

## Toolchain contract

The selected baseline is AGP 8.6.1, Gradle 8.7, JDK 17, Kotlin 1.9.0, and compile SDK 35. The Gradle wrapper is not included in this archive, and the current environment did not have a `gradle` executable available. Therefore dependency resolution, Android compilation, and APK production have not been verified in this stage.

## Device identity remains unregistered

The supplied package name is `com.mojang.minecraftpe`; the user-provided SHA-256 is `b369922ee3e720f359b9eec13af554dc87a0ec09f3ac49e7e123bc94fb985890`. The displayed version `1.26.13.1 (792601301)` is not accepted as Android `versionCode` until read by `PackageManager` on-device. `AndroidGameDiscovery` must collect the version code and current signer digest itself before a build can be registered as supported.

## Next step

Add a minimal `:app` Android application module with a launcher Activity that calls `AndroidGameDiscovery`, displays `Found` / `NotInstalled` / `Unknown`, and does not launch or modify Minecraft. Then verify on a real Android 13 device.

# Android Game Discovery — Stage 6

## What is added

`android-integration/.../AndroidGameDiscovery.kt` is the Android platform adapter for the existing platform-neutral `GameBuildFingerprint` and `GameBuildRegistry`.

It reads one explicitly configured package through `PackageManager`, obtains the real Android `longVersionCode` (or the legacy `versionCode` on older Android releases), reads the current APK signer certificate(s), and calculates SHA-256 over each certificate's encoded bytes.

The adapter returns `NotInstalled` when Android reports that the package is absent, and `Unknown` when evidence cannot safely be read. It does not grant compatibility or modify Minecraft.

## Package visibility

The app manifest at `app/src/main/AndroidManifest.xml` declares visibility for only `com.mojang.minecraftpe`, not all installed applications. The library manifest also contains the query so consumers of the adapter inherit the requirement through manifest merging. Android 11+ package-visibility filtering can otherwise make an installed app appear unavailable to package queries.

## Signature semantics

On Android 9/API 28+, the adapter hashes `SigningInfo.apkContentsSigners`, i.e. the certificates currently signing the installed APK. It intentionally does not use the full signing-certificate history as the current signer set. On older Android versions it uses the legacy `PackageInfo.signatures` field.

## Important correction about the supplied screenshot

The App Info screen visibly shows `com.mojang.minecraftpe` and display version `1.26.13.1 (792601301)`. The number in parentheses is not yet verified as Android `versionCode`; only the `PackageManager` result can establish that. The supplied Signatures screen shows SHA-256:

`b369922ee3e720f359b9eec13af554dc87a0ec09f3ac49e7e123bc94fb985890`

The value is a correctly formatted SHA-256 fingerprint and matches the value typed by the user. The Android adapter must calculate its own value and compare it before the build is registered. Until the actual `longVersionCode` and adapter-collected signer digest are obtained on-device, this installation must remain `Unknown` in the registry.

## Integration example

```kotlin
val discovery = AndroidGameDiscovery(context)
when (val result = discovery.inspect("com.mojang.minecraftpe")) {
    is GameDiscoveryResult.Found -> {
        val match = gameBuildRegistry.match(result.fingerprint)
        // Show Supported only for GameBuildMatch.Supported; otherwise show Unknown.
    }
    is GameDiscoveryResult.NotInstalled -> {
        // Show that the target package is not installed or not visible.
    }
    is GameDiscoveryResult.Unknown -> {
        // Show the reason; never assume compatibility.
    }
}
```

## Not yet verified

- Android Gradle module wiring and dependency resolution.
- Compilation against the project's chosen compileSdk/minSdk.
- Runtime behavior on the user's Samsung SM-A225F / Android 13 device.
- Actual PackageManager versionCode and certificate digest for the installed game.
- Split APK / artifact hashing.

This source is an integration component, not a built APK. No game launch, mod injection, offline mode, or LAN behavior is implemented by this stage.

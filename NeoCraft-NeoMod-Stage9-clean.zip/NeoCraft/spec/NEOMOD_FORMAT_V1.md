# NeoMod package format v1

## 1. Container

A `.nmod` file is a ZIP archive. The archive root must contain `manifest.json` encoded as UTF-8. Package paths use POSIX separators (`/`). Absolute paths, `..`, backslashes, duplicate paths, case-only path collisions and symbolic links are rejected.

Reference validator limits: 10,000 archive entries, 160 MiB compressed archive size, 32 MiB per file, 128 MiB total uncompressed content, and 256 KiB for `manifest.json`. ZIP64 and multi-disk archives are not supported in v1.

## 2. Identity and versioning

- `id`: stable lowercase reverse-DNS ID. It must not change when the display name changes.
- `version`: stable `MAJOR.MINOR.PATCH`; prerelease/build metadata is not part of v1.
- Dependency constraints: comma-separated AND clauses using `>=`, `<=`, `>`, `<`, `=` or a bare exact version. Example: `>=1.2.0,<2.0.0`.

## 3. Resources

Every resource has a package-local `source`, a virtual game `target`, and a declared `capability`. Sources must exist in the archive. Targets are normalized relative paths. Two resources in one package cannot share a target; two enabled packages cannot map to the same target in v1. There is no implicit load-order override.

## 4. Dependencies and conflicts

Required dependencies must be present in the enabled profile and satisfy their version constraint. Optional dependencies may be absent, but if present they must satisfy the declared constraint. Dependency cycles are rejected. A declared conflict in either package is enough to reject the combined profile.

## 5. Capabilities

V1 capability identifiers: `textures`, `sounds`, `models`, `ui`, `behavior_data`, `scripts`. A package must declare every capability used by its resources. `scripts` and `entrypoint` are metadata only in this prototype; scripts are not executed.

## 6. Isolation boundary

NeoMod guarantees namespace separation for launcher-managed metadata/configuration only when the future launcher stores each mod under a path derived from its immutable ID. It does not sandbox arbitrary native code, prevent all gameplay-level interactions, or prove two content packages are semantically compatible.

## 7. Game integration boundary

The `game.versions` values are compatibility declarations, not proof. The launcher must compare them against the detected game build. A Bedrock adapter must separately define which resource types can be safely materialized and how the selected Minecraft PE Patched build loads them. Until that adapter is implemented and tested, `.nmod` is a package/management format, not a working in-game mod loader.

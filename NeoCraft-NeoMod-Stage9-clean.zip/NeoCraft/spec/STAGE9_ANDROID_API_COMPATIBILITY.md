# Stage 9 — Android API compatibility correction

## Issue found during review

The Stage 8 Gradle files declared `minSdk = 23`, but the existing Kotlin package manager uses `java.nio.file.Path`, `Files`, `LinkOption`, and related NIO file APIs. Android's API reference marks these APIs as available from API 26. Advertising API 23 support would therefore be inaccurate for the complete NeoMod package-management feature set.

The same source also used `Files.readString` and `Files.writeString`. Android's API reference lists these methods only in API 36.1, so they are not safe on the user's Android 13 / API 33 device.

## Changes

- Replaced `Files.readString` with `String(Files.readAllBytes(...), UTF_8)`.
- Replaced `Files.writeString` with `Files.newOutputStream(...).use { write(UTF_8 bytes) }`, retaining the existing temporary-file + atomic-move transaction pattern.
- Raised `minSdk` to 26 in both `:app` and `:android-integration`, matching the API floor for `java.nio.file`.
- Updated README and setup/discovery docs so they no longer describe Stage 8's Android app as still pending or give the old archive folder name.

## Verification

The platform-neutral Kotlin self-tests and Python reference tests were rerun after these edits. This verifies the core logic on the current JDK, not Android runtime linkage. A real Android Gradle build and device test are still required.

## References

- Android `java.nio.file.Files` API reference: https://developer.android.com/reference/java/nio/file/Files
- The reference marks `readAllBytes` and related NIO APIs as added in API 26, while `readString` is marked as added in API 36.1.

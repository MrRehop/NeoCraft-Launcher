# Stage 8 — minimal Android app and CI

## Added
- `:app` Android application module with a native Activity.
- Launcher screen with a button that calls `AndroidGameDiscovery`.
- Explicit package visibility query for `com.mojang.minecraftpe`.
- GitHub Actions workflow building `:app:assembleDebug` and uploading the APK artifact.

## Important limitations
- This stage has not been compiled with Gradle or installed on a device.
- A successful CI run is required before claiming an APK exists.
- The screen reports discovered identity only. It deliberately does not mark the game compatible or launch/modify Minecraft.
- User-provided version display and certificate fingerprint are not hardcoded as trusted build identity.
- The GitHub Actions workflow is configured for Gradle 8.7 and JDK 17 with AGP 8.6.1. Compatibility still requires a successful CI run.

## GitHub setup from Android
1. Create a new public or private repository named `NeoCraft-Launcher`.
2. Extract the Stage 8 archive on the phone.
3. Upload the *contents* of the archive’s top-level `NeoCraft/` folder to the repository root (not an extra enclosing folder).
4. Ensure `.github/workflows/android-apk.yml` is present in the repository.
5. Open the repository's Actions tab and inspect `Build NeoCraft Android APK`.
6. Only download `neocraft-debug-apk` if the workflow finishes successfully.

## Next
Resolve any CI errors, then install the debug APK on the Samsung device and test package discovery.

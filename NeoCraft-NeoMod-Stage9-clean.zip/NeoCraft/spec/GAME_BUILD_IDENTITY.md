# Game build identity and matching policy

- Status: platform-neutral core plus Android discovery adapter (source prepared; Android build not verified)
- Date: 2026-11-13
- Scope: NeoCraft / NeoMod compatibility boundary

## Why this exists

The visible version string in Android App info is useful for triage but is not a unique identity for a patched APK. Two packages can display the same version while having different package IDs, version codes, signatures, or APK contents.

## Identity evidence

The core matcher accepts a `GameBuildFingerprint` containing:

- exact Android package name;
- Android `versionCode` (not the display `versionName`);
- the set of current APK signing-certificate SHA-256 digests;
- optional digests for specifically named APK/split artifacts.

`versionName` is retained for diagnostics only. It is never sufficient to recognize a build.

A reviewed `SupportedGameBuild` record requires package name, positive version code, and at least one valid 64-character SHA-256 signer digest. A record may additionally require exact digests for selected APK artifacts.

## Matching policy

A build is recognized only when all of the following match:

1. package name and version code select exactly one reviewed registry record;
2. the complete current signer-digest set matches;
3. every artifact digest required by that record is present and matches.

Missing or malformed evidence returns `Unknown`. Duplicate registry entries for the same package name and version code are rejected at registry construction. There is no fallback to version-name matching or partial matching.

Recognition is not permission to modify the game. It only identifies a build record. Capabilities such as resource import, script loading, offline launch, and LAN multiplayer must be verified separately and granted explicitly by a future adapter.

## Android collection notes

The source adapter is now prepared at `android-integration/.../AndroidGameDiscovery.kt`. It reads `PackageInfo`, obtains `longVersionCode`, and calculates SHA-256 digests of current signing certificates exposed by `SigningInfo` on API 28+. It uses the legacy signature field on older Android versions and the API-33 `PackageInfoFlags` overload where available. Merge `android-integration/manifest-queries.xml` into the app manifest to request visibility only for the known target package. Android compilation and device runtime testing remain outstanding.

APK/split artifact hashing is intentionally left outside the pure Kotlin core. The Android layer must define which artifacts are stable and obtainable on supported Android versions before a registry record can require them.

## Test coverage added

- exact match;
- `versionName` is not used as identity;
- unknown package rejection;
- version-code mismatch rejection;
- signer mismatch and missing signer rejection;
- missing and mismatched required artifact digest rejection;
- duplicate registry record rejection.

The test digests in the self-tests are synthetic fixtures, not hashes from the user's installed Minecraft build.

## Current target status

The user-provided App Info screenshot shows package name `com.mojang.minecraftpe` and display version `1.26.13.1 (792601301)`. The number in parentheses has not yet been verified as Android `versionCode`. The Signatures screenshot shows SHA-256 `b369922ee3e720f359b9eec13af554dc87a0ec09f3ac49e7e123bc94fb985890`; it matches the user-entered value, but the Android adapter has not independently collected it. Therefore no real Minecraft build is registered or recognized yet. See `ANDROID_GAME_DISCOVERY.md`.

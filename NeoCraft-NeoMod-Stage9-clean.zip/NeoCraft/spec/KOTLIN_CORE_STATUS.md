# NeoMod Kotlin Core — implementation status

## Implemented

- Kotlin data models for manifests, dependencies, resources and packages.
- Stable semantic-version parser and dependency constraint evaluator.
- Manifest-level validation for IDs, versions, game target, capabilities, resource paths, resource declarations and entrypoint metadata.
- Profile validation for duplicate IDs, missing required dependencies, dependency version mismatches, declared conflicts, dependency cycles and cross-package resource target collisions.
- Dependency-free strict JSON parser and NeoMod v1 manifest decoder.
- Read-only `.nmod` ZIP inspector with bounded streaming, path checks, duplicate/case-collision checks, CRC validation, Unix symlink/special-file rejection, UTF-8 validation and manifest-to-model conversion.
- Local package manager with ID/version storage, staged extraction, SHA-256 source-change checks, atomic install commit, multiple installed versions, profile persistence, profile validation, active-profile enable/disable and guarded uninstall.
- Dependency-free JVM self-test harness.

## Latest validation

- Kotlin core/profile tests: 14/14 passed.
- Kotlin package-reader tests: 14/14 passed.
- Kotlin package-manager tests: 11/11 passed.
- Game-build identity tests: 9/9 passed.
- Combined Kotlin direct-compiler tests: 48/48 passed.
- Python reference tests: 10/10 passed.
- Toolchain used for Kotlin direct compilation: Kotlin compiler 1.9.0, JDK 21.

Gradle is not installed in the current work environment, so the Gradle task and Android build have not been run. The direct Kotlin compiler script was run instead.

## Not implemented yet

- Package signatures, publisher trust and persistent installed-file integrity index.
- Multi-process/concurrent-store locking.
- Full Android NeoMod storage integration and production UI (only a minimal discovery Activity exists).
- Minecraft Bedrock runtime adapter or script execution.
- Resource activation/materialization into a selected game build.
- Offline/LAN multiplayer.

The package manager manages files and launcher profiles only. `.nmod` is not yet a working in-game mod loader.

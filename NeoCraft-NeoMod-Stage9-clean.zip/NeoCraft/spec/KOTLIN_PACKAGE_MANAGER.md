# NeoMod Package Manager — Stage 4

## Scope

`NeoModPackageManager` manages local `.nmod` package files and launcher-side profiles. It is platform-neutral Kotlin/JVM code. It does not execute scripts, inject code into Minecraft, materialize game resources into a Minecraft directory, or implement runtime sandboxing.

## Storage layout

```text
<launcher-private-storage>/neomod/
├── active-profile
├── packages/
│   └── org.example.mod/
│       └── 1.0.0/
│           ├── manifest.json
│           └── ... package files ...
└── profiles/
    ├── default.profile
    └── creative.profile
```

- Package identity is stored under immutable `ID/version` paths.
- Multiple versions of the same ID may coexist.
- A profile selects at most one version for each ID.
- `active-profile` contains the selected profile name.
- Profile files use the `NEOMOD_PROFILE_V1` header followed by tab-separated `id` and `version` pairs.
- Package files are stored independently of profile activation; disabling a package does not delete it.

## API

```kotlin
val manager = NeoModPackageManager(File(context.filesDir, "neomod"))

// Validate, extract to a staging directory, then atomically move into ID/version storage.
val installed = manager.install(selectedNmodFile)

// Create or replace a profile after checking dependencies and conflicts.
manager.saveProfile("creative", mapOf("org.example.mod" to "1.0.0"))
manager.activateProfile("creative")

// Convenience toggle in the active profile; invalid dependency combinations are rejected.
manager.setEnabled("org.example.mod", "1.0.0", true)
manager.setEnabled("org.example.mod", "1.0.0", false)

// A package cannot be uninstalled while any saved profile references that exact version.
manager.uninstall("org.example.mod", "1.0.0")
```

## Installation behavior

1. The source must be a regular `.nmod` file and fit the configured archive limit.
2. The source file is SHA-256 hashed before inspection.
3. `NeoModPackageReader` validates the archive without extraction.
4. The source hash is checked again to detect changes during inspection.
5. Files are streamed into a unique staging directory under the package store. Entry and total decompressed limits are rechecked while copying.
6. The extracted manifest and file list are validated again.
7. The source hash is checked once more.
8. The staging directory is moved to the final `ID/version` directory using `ATOMIC_MOVE`. If the filesystem does not support atomic moves, installation fails rather than silently falling back to a non-atomic copy.

A failed pre-commit installation removes its staging directory. Existing installed package versions are not overwritten; attempting to install the same ID/version again is rejected.

## Profiles and activation

- Saving and activation both validate the selected package set with `NeoModValidator.validateProfile`.
- Required dependencies, version constraints, declared conflicts, dependency cycles and resource-target collisions are checked.
- Profile files and the active-profile pointer are written through a temporary sibling file and atomic replacement.
- `setEnabled` edits only the active profile. It does not remove package files.

## Uninstall behavior

Uninstall is refused while any saved profile references the exact ID/version. Once no profile references it, the package directory is atomically detached to a hidden trash path and then recursively deleted. If cleanup fails after detachment, the error reports the leftover trash path; uninstall cleanup is not a transactional rollback.

## Important limitations

- Use one `NeoModPackageManager` instance per storage root. Concurrent mutation through multiple instances or multiple processes is not supported in this prototype.
- Installed package contents are validated when listed, but package signatures, publisher identity and a persistent cryptographic file index are not implemented.
- The current profile is a launcher-side selection only. It does not prove that Minecraft can load the selected content.
- `scripts` and `entrypoint` remain metadata. No package code is executed.
- The JVM test suite was run with Kotlin compiler 1.9.0 and JDK 21. Android API compatibility, storage permissions and Gradle/Android packaging have not been verified.

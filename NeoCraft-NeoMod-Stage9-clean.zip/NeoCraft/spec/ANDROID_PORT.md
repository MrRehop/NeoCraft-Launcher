# Android port plan

The reference validator is intentionally platform-neutral. The Android implementation should be split into modules:

- `:app` — Jetpack Compose screens, navigation, user actions.
- `:neomod-core` — manifest model, parser, path checks, dependency/profile validation; no Android UI or Minecraft-specific code.
- `:neomod-storage` — app-private package storage, per-mod config directories, enable/disable state, import/export.
- `:game-adapter-bedrock` — version detection and the explicitly verified integration mechanism for one supported Minecraft PE Patched build.
- `:lan` — later LAN discovery/connection support, kept independent of mod package parsing.

Suggested private storage layout:

```text
files/neomod/
  packages/<mod-id>/<version>.nmod
  configs/<mod-id>/...
  profiles/default.json
  cache/
```

The ID must be validated before it is used in a filesystem path. Package imports should be copied into app-private storage, validated before becoming enabled, and never extracted using untrusted archive paths without the same path/size checks as the reference validator.

No Gradle project or APK is claimed in this stage. The next implementation task is to port the manifest model and profile validator to Kotlin and run JVM unit tests before connecting Android UI.

#!/usr/bin/env python3
"""Build a ZIP-based .nmod archive from a package directory."""
import argparse
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a .nmod package")
    parser.add_argument("source", type=Path, help="Directory containing manifest.json")
    parser.add_argument("output", type=Path, help="Output .nmod path")
    args = parser.parse_args()

    source = args.source.resolve()
    manifest = source / "manifest.json"
    if not source.is_dir() or not manifest.is_file():
        parser.error("source must be a directory containing manifest.json")
    try:
        json.loads(manifest.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        parser.error(f"manifest.json is not valid UTF-8 JSON: {exc}")

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, "w", compression=ZIP_DEFLATED) as archive:
        for item in sorted(source.rglob("*")):
            if item.is_symlink():
                parser.error(f"symbolic links are not allowed: {item}")
            if item.is_file():
                relative = item.relative_to(source).as_posix()
                archive.write(item, relative)
    print(f"Created {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

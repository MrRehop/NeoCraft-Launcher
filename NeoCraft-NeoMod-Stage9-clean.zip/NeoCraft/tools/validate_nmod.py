#!/usr/bin/env python3
"""Validate one or more .nmod packages and their combined profile."""
import argparse
import sys
from neomod.core import NeoModError, load_package, validate_profile


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate NeoMod packages/profile")
    parser.add_argument("packages", nargs="+", help="One or more .nmod files")
    args = parser.parse_args()
    loaded = []
    failed = False
    for path in args.packages:
        try:
            package = load_package(path)
            loaded.append(package)
            print(f"PACKAGE OK  {package.mod_id} {package.version}  ({path})")
        except (OSError, NeoModError) as exc:
            failed = True
            print(f"PACKAGE ERROR  {path}: {exc}", file=sys.stderr)
    if loaded:
        errors = validate_profile(loaded)
        if errors:
            failed = True
            for error in errors:
                print(f"PROFILE ERROR  {error}", file=sys.stderr)
        else:
            print(f"PROFILE OK  {len(loaded)} package(s); no declared conflicts or target collisions found")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())

# NeoCraft Android integration currently uses no reflection-based entry points.
# Keep this file so the library can add consumer rules without changing module wiring.

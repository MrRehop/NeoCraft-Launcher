package org.neocraft.neomod.android

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import org.neocraft.neomod.core.GameBuildFingerprint
import java.security.MessageDigest

/** Reads identity evidence for one explicitly configured game package. */
class AndroidGameDiscovery(private val context: Context) {
    fun inspect(packageName: String): GameDiscoveryResult {
        if (packageName.isBlank()) {
            return GameDiscoveryResult.Unknown("Target package name is blank")
        }

        val packageInfo = try {
            getPackageInfo(packageName)
        } catch (_: PackageManager.NameNotFoundException) {
            return GameDiscoveryResult.NotInstalled(packageName)
        } catch (error: SecurityException) {
            return GameDiscoveryResult.Unknown(
                "Android denied package visibility: ${error.message ?: "no details"}"
            )
        } catch (error: RuntimeException) {
            return GameDiscoveryResult.Unknown(
                "Could not read package information: ${error.message ?: error.javaClass.simpleName}"
            )
        }

        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            packageInfo.versionCode.toLong()
        }
        if (versionCode <= 0L) {
            return GameDiscoveryResult.Unknown("Installed package returned an invalid versionCode")
        }

        val signers = try {
            currentSignerCertificates(packageInfo)
        } catch (error: RuntimeException) {
            return GameDiscoveryResult.Unknown(
                "Could not read signing certificates: ${error.message ?: error.javaClass.simpleName}"
            )
        }
        if (signers.isEmpty()) {
            return GameDiscoveryResult.Unknown("No current signing certificates are available")
        }

        return GameDiscoveryResult.Found(
            GameBuildFingerprint(
                packageName = packageInfo.packageName,
                versionCode = versionCode,
                versionName = packageInfo.versionName,
                signingCertificateSha256 = signers.map(::sha256).toSet(),
            )
        )
    }

    @Suppress("DEPRECATION")
    private fun getPackageInfo(packageName: String): PackageInfo {
        val pm = context.packageManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageInfo(
                packageName,
                PackageManager.PackageInfoFlags.of(PackageManager.GET_SIGNING_CERTIFICATES.toLong()),
            )
        } else {
            pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        }
    }

    @Suppress("DEPRECATION")
    private fun currentSignerCertificates(info: PackageInfo): List<Signature> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signingInfo = info.signingInfo
                ?: return emptyList()
            // apkContentsSigners are the certificates currently signing this install.
            // Do not compare signing history as if every historical signer were current.
            signingInfo.apkContentsSigners?.toList().orEmpty()
        } else {
            info.signatures?.toList().orEmpty()
        }
    }

    private fun sha256(signature: Signature): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
        return digest.joinToString(separator = "") { byte -> "%02x".format(byte) }
    }
}

sealed interface GameDiscoveryResult {
    data class Found(val fingerprint: GameBuildFingerprint) : GameDiscoveryResult
    data class NotInstalled(val packageName: String) : GameDiscoveryResult
    data class Unknown(val reason: String) : GameDiscoveryResult
}
